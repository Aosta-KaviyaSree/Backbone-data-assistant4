# Admin guide: logins, formulas and segments

## 1. First start
Open the app. The first person to sign up becomes the **admin** (set ADMIN_USER / ADMIN_PASSWORD in `.env` when hosting, so nobody else can claim it). After that, public sign-up is closed: the admin creates logins in **Admin > Users** (or switches on self sign-up there).

## 2. Why formulas?
Without a formula the AI may count rows, so a ticket with several lines is counted several times. Formulas make the numbers exact and identical for everyone. Admin page: `/admin.html` (the **Admin** button in the chat; only admins see it).

## 3. Admin > Formulas
Pick a dataset on the left. Click a column chip to insert it where your cursor is. Each formula is checked live against the data (result or a clear error).
- **Measures** (numbers). Examples for a ticketing dataset:
```
Total Tickets  = DISTINCTCOUNT('Tickets'[Tick No])
Open Tickets   = CALCULATE([Total Tickets], 'Tickets'[Status] IN {"Open","In Progress"})
Closed Tickets = CALCULATE([Total Tickets], 'Tickets'[Status] = "Closed")
Open %         = DIVIDE([Open Tickets], [Total Tickets])
Avg Hours      = AVERAGE('Tickets'[Resolution Hours])
```
- **Segments** (named filters), used with any measure: `Open = 'Tickets'[Status] IN {"Open","In Progress"}`, `High priority = 'Tickets'[Priority] = "High"`. "Open tickets by department" then = measure Total Tickets + segment Open, grouped by Department.
- **Business notes**: rules in plain words.
Press **Save all**. Users get the new formulas on their next question (no restart). Users can read definitions (not edit) under **Definitions**.

## 4. Supported formula language (a practical subset of DAX)
DISTINCTCOUNT, COUNT, COUNTROWS, SUM, AVERAGE, MIN, MAX, CALCULATE (with filters, FILTER, ALL), DIVIDE, IF, SWITCH, AND/OR/NOT, && and ||, IN { }, ISBLANK, COALESCE, ROUND, ABS, YEAR, MONTH, DAY, TODAY, DATE, UPPER, LOWER, CONTAINSSTRING, and references to other measures like [Total Tickets]. Table names are optional (formulas run on the selected dataset). Not supported: relationships between tables, SUMX/iterators, time-intelligence functions (SAMEPERIODLASTYEAR etc.). Anything unsupported shows a clear message.

## 5. Where things are stored
`data/formulas.json`, `data/users.json` (passwords are hashed), uploaded CSVs. On a free host these folders are erased on restart: set `DATA_DIR` to a persistent disk, or keep copies. Live SQL Server mode uses `module.config.json` (T-SQL KPIs, see SQL_SETUP.md) instead of this page.

## 6. Security notes
Passwords: 8+ characters, stored with scrypt. Login tokens last 12 hours. Five wrong passwords lock that login for a minute. Admin actions are enforced on the server, not just hidden in the page.
