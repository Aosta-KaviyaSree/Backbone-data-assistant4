import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { parse } from 'csv-parse/sync';
import { createAuth } from './auth.js';
import { createFormulas } from './formulas.js';
import { loadModule, createSqlRuntime, makeExecutor, mockExecutor } from './sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const P = process.env;
/* Free LLM providers (all OpenAI-compatible). Pick one with PROVIDER in .env */
const PRESETS = {
  gemini: { base: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-3.8-flash', key: P.GEMINI_API_KEY },
  groq: { base: 'https://api.groq.com/openai/v1', model: 'llama-3.3-70b-versatile', key: P.GROQ_API_KEY },
  ollama: { base: 'http://localhost:11434/v1', model: 'qwen2.5:7b', key: '' },
};
const PROVIDER = (P.PROVIDER || 'gemini').toLowerCase();
const pre = PRESETS[PROVIDER] || {};
const BASE = (P.LLM_BASE_URL || pre.base || '').replace(/\/$/, '');
let MODEL = P.MODEL || pre.model;
/* Gemini model names get retired often: unless MODEL is set, use the newest plain "flash" model the key can see */
async function pickModel() {
  if (P.MODEL || PROVIDER !== 'gemini' || !KEY) return;
  try {
    const j = await (await fetch(`${BASE}/models`, { headers: { Authorization: `Bearer ${KEY}` } })).json();
    const ids = (j.data || []).map(m => String(m.id).replace(/^models\//, '')).filter(id => /^gemini-[\d.]+-flash$/.test(id)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
    if (ids.length) MODEL = ids[ids.length - 1];
  } catch { /* keep preset */ }
}
const KEY = P.LLM_API_KEY || pre.key || '';
const app = express();
app.use(express.json({ limit: '60mb' }));
app.use((req, res, next) => {
  // allow embedding in Power BI / Power Apps / Teams, and mic access
  res.setHeader('Content-Security-Policy', `frame-ancestors 'self' ${process.env.FRAME_ANCESTORS || 'https://*.powerbi.com https://*.powerapps.com https://teams.microsoft.com'}`);
  res.setHeader('Permissions-Policy', 'microphone=(self)');
  next();
});
/* Optional shared access key for a hosted deployment: every /api call must send it (the Power BI link carries ?key=...) */
const ACCESS_KEY = process.env.ACCESS_KEY || '';
app.use('/api', (req, res, next) => (!ACCESS_KEY || req.get('x-access-key') === ACCESS_KEY || req.query.key === ACCESS_KEY ? next() : res.status(401).json({ error: 'Access key required. Open the assistant from the link that includes ?key=...' })));

/* ---------------- Accounts and roles (admin / user) ---------------- */
const AUTH = createAuth(process.env.DATA_DIR || path.join(__dirname, 'data'));
if (!AUTH.hasUsers() && process.env.ADMIN_USER && process.env.ADMIN_PASSWORD) {
  try { AUTH.create({ username: process.env.ADMIN_USER, password: process.env.ADMIN_PASSWORD, role: 'admin' }); console.log('Admin account created from ADMIN_USER / ADMIN_PASSWORD.'); } catch (e) { console.error('Could not create the admin account:', e.message); }
}
const clientIp = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '';
app.get('/api/auth/state', (req, res) => res.json({ hasUsers: AUTH.hasUsers(), allowSignup: AUTH.settings().allowSignup }));
app.post('/api/auth/login', (req, res) => { try { res.json(AUTH.login(req.body.username, req.body.password, clientIp(req))); } catch (e) { res.status(401).json({ error: e.message }); } });
app.post('/api/auth/signup', (req, res) => {
  try {
    const first = !AUTH.hasUsers();
    if (!first && !AUTH.settings().allowSignup) return res.status(403).json({ error: 'Sign-up is closed. Ask your administrator for an account.' });
    AUTH.create({ username: req.body.username, password: req.body.password, role: first ? 'admin' : 'user' });
    res.json(AUTH.login(req.body.username, req.body.password, clientIp(req)));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.use('/api', (req, res, next) => { const u = AUTH.verify((req.get('authorization') || '').replace(/^Bearer\s+/i, '')); if (!u) return res.status(401).json({ error: 'Please log in.', auth: true }); req.user = u; next(); });
const adminOnly = (req, res, next) => (req.user && req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Administrators only.' }));
app.get('/api/auth/me', (req, res) => res.json({ user: req.user }));
app.post('/api/auth/password', (req, res) => { try { AUTH.changeOwnPassword(req.user.id, req.body.oldPassword, req.body.newPassword); res.json({ ok: true }); } catch (e) { res.status(400).json({ error: e.message }); } });
app.get('/api/admin/users', adminOnly, (req, res) => res.json({ users: AUTH.list(), settings: AUTH.settings() }));
app.post('/api/admin/users', adminOnly, (req, res) => { try { res.json({ user: AUTH.create(req.body) }); } catch (e) { res.status(400).json({ error: e.message }); } });
app.patch('/api/admin/users/:id', adminOnly, (req, res) => { try { res.json({ user: AUTH.update(req.params.id, req.body) }); } catch (e) { res.status(400).json({ error: e.message }); } });
app.delete('/api/admin/users/:id', adminOnly, (req, res) => { try { if (req.params.id === req.user.id) throw new Error('You cannot delete your own account.'); AUTH.remove(req.params.id); res.json({ ok: true }); } catch (e) { res.status(400).json({ error: e.message }); } });
app.put('/api/admin/settings', adminOnly, (req, res) => { AUTH.setSettings(req.body); res.json({ settings: AUTH.settings() }); });
app.use(express.static(path.join(__dirname, 'public')));

/* ---------------- Data: CSV files in ./data ---------------- */
const num = (v, dc = false) => {
  if (typeof v === 'number') return v;
  let x = String(v).replace(/[₹$€£%\s]/g, '');
  x = dc && !x.includes('.') ? x.replace(',', '.') : x.replace(/,/g, '');
  return /^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/i.test(x) ? parseFloat(x) : null;
};
/* Dates: yyyy-mm-dd, dd-mm-yyyy (day first; month first only if the 2nd number is > 12), optional hh:mm */
function toDate(v) {
  const s = String(v).trim(); let m;
  const mk = (y, mo, d, h, mi) => { const dt = new Date(Date.UTC(+y, +mo - 1, +d, +(h || 0), +(mi || 0))); return dt.getUTCMonth() === +mo - 1 ? dt : null; };
  if ((m = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T\s]+(\d{1,2}):(\d{2}))?/))) return mk(m[1], m[2], m[3], m[4], m[5]);
  if ((m = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})(?:[T\s]+(\d{1,2}):(\d{2}))?/))) return +m[2] > 12 ? mk(m[3], m[1], m[2], m[4], m[5]) : mk(m[3], m[2], m[1], m[4], m[5]);
  return null;
}
const isoOf = d => { const i = d.toISOString(); return i.slice(0, i.slice(11, 16) === '00:00' ? 10 : 16).replace('T', ' '); };
function bucketOf(v, b) {
  const d = toDate(v); if (!d) return null;
  const y = d.getUTCFullYear(), mo = d.getUTCMonth() + 1, p = n => String(n).padStart(2, '0');
  return b === 'year' ? String(y) : b === 'quarter' ? `${y}-Q${Math.ceil(mo / 3)}` : b === 'month' ? `${y}-${p(mo)}` : b === 'day' ? `${y}-${p(mo)}-${p(d.getUTCDate())}`
    : b === 'weekday' ? ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getUTCDay()] : b === 'hour' ? p(d.getUTCHours()) : null;
}
const TABLES = {};
const dir = process.env.DATA_DIR || path.join(__dirname, 'data'); // datasets, formulas.json, users.json live here
fs.mkdirSync(dir, { recursive: true });
const safeName = n => String(n).replace(/\.[^.]+$/, '').replace(/[^\p{L}\p{N}_]+/gu, '_').replace(/^_+|_+$/g, '') || 'table';
function registerTable(name, text, persist = true) {
  text = String(text || '').replace(/^\uFEFF/, '');
  const first = text.split(/\r?\n/)[0] || '';
  const delimiter = [',', ';', '\t'].map(d => [d, first.split(d).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = parse(text, { columns: h => h.map((x, i) => String(x).trim() || `col${i + 1}`), skip_empty_lines: true, trim: true, relax_column_count: true, delimiter });
  if (!rows.length) throw new Error('No data rows found (the first row must be the column headers).');
  const cols = Object.keys(rows[0]), types = {};
  const dc = delimiter === ';';
  for (const c of cols) {
    const v = rows.map(r => r[c]).filter(x => x !== '' && x != null);
    const frac = f => v.length && v.filter(f).length / v.length >= 0.9;
    types[c] = /(^|_)id$/i.test(c) ? 'text' : frac(x => toDate(x)) ? 'date' : frac(x => num(x, dc) !== null) ? 'number' : 'text';
  }
  for (const r of rows) for (const c of cols) {
    if (types[c] === 'number') r[c] = num(r[c], dc);
    else if (types[c] === 'date') { const d = toDate(r[c]); r[c] = d ? isoOf(d) : null; }
  }
  const ranges = {};
  for (const c of cols) if (types[c] === 'date') { const v = rows.map(r => r[c]).filter(Boolean).sort(); ranges[c] = v.length ? `${v[0]} to ${v[v.length - 1]}` : ''; }
  TABLES[name] = { rows, cols, types, ranges };
  if (persist) fs.writeFileSync(path.join(dir, name + '.csv'), text);
}
for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.csv'))) {
  try { registerTable(safeName(f), fs.readFileSync(path.join(dir, f), 'utf8'), false); } catch { /* skip bad file */ }
}
const schemaNotes = fs.existsSync(path.join(dir, 'schema.md')) ? fs.readFileSync(path.join(dir, 'schema.md'), 'utf8') : '';
const tablesInfo = () => Object.entries(TABLES).map(([k, t]) => `- ${k} (${t.rows.length} rows): ` + t.cols.map(c => {
  const eg = t.types[c] === 'text' ? [...new Set(t.rows.slice(0, 5000).map(r => r[c]))].slice(0, 6).join(' | ') : t.types[c] === 'date' ? (t.ranges[c] || '') : '';
  return `${c} [${t.types[c]}${eg ? ': ' + eg : ''}]`;
}).join(', ')).join('\n') || '(no data loaded yet - ask the user to click "Upload data" and add a CSV or Excel file)';

const lc = x => String(x).toLowerCase();
const cmp = (t, a, b) => (t === 'number' ? [a, Number(b)] : [String(a), String(b)]);
const OPS = {
  '=': (a, b) => lc(a) === lc(b), '!=': (a, b) => lc(a) !== lc(b),
  '>': (a, b, t) => { [a, b] = cmp(t, a, b); return a > b; }, '<': (a, b, t) => { [a, b] = cmp(t, a, b); return a < b; },
  '>=': (a, b, t) => { [a, b] = cmp(t, a, b); return a >= b; }, '<=': (a, b, t) => { [a, b] = cmp(t, a, b); return a <= b; },
  contains: (a, b) => lc(a).includes(lc(b)), in: (a, b) => (Array.isArray(b) ? b : String(b).split(',')).map(x => lc(x).trim()).includes(lc(a)),
};

function queryData({ table, filters = [], group_by = [], time_bucket, metrics = [], select, order_by, desc = true, limit = 50 }) {
  const t = TABLES[table];
  if (!t) return { error: `Unknown table. Available: ${Object.keys(TABLES).join(', ')}` };
  const used = [...group_by, ...(time_bucket ? [time_bucket.column] : []), ...(select || []), ...filters.map(f => f.column), ...metrics.map(m => m.column).filter(Boolean)];
  const bad = used.find(c => !t.cols.includes(c));
  if (bad) return { error: `Unknown column "${bad}". Columns: ${t.cols.join(', ')}` };
  if (time_bucket && t.types[time_bucket.column] !== 'date') return { error: `"${time_bucket.column}" is not a date column. Date columns: ${t.cols.filter(c => t.types[c] === 'date').join(', ') || 'none'}` };
  const nb = metrics.find(m => ['sum', 'avg', 'min', 'max'].includes(m.agg) && t.types[m.column] !== 'number');
  if (nb) return { error: `Cannot ${nb.agg} "${nb.column}" (not numeric). Use count or count_distinct for it. Numeric columns: ${t.cols.filter(c => t.types[c] === 'number').join(', ')}` };
  let rows = t.rows.filter(r => filters.every(f => OPS[f.op] && OPS[f.op](r[f.column], f.value, t.types[f.column])));
  let out;
  if (!group_by.length && !metrics.length) {
    out = rows.map(r => (select ? Object.fromEntries(select.map(c => [c, r[c]])) : r));
  } else {
    const tbName = time_bucket && (time_bucket.as || `${time_bucket.column}_${time_bucket.bucket}`);
    const groups = new Map();
    for (const r of rows) {
      const b = time_bucket ? bucketOf(r[time_bucket.column], time_bucket.bucket) : '';
      if (b === null) continue;
      const k = JSON.stringify([...group_by.map(c => r[c]), b]);
      (groups.get(k) || groups.set(k, []).get(k)).push(r);
    }
    out = [...groups.values()].map(rs => {
      const o = {};
      group_by.forEach(c => (o[c] = rs[0][c]));
      if (time_bucket) o[tbName] = bucketOf(rs[0][time_bucket.column], time_bucket.bucket);
      for (const m of metrics) {
        const name = m.as || `${m.agg}_${m.column || 'rows'}`;
        const v = rs.map(r => r[m.column]).filter(x => x !== null && x !== undefined && x !== '');
        const s = v.reduce((a, b) => a + b, 0);
        o[name] = m.agg === 'count' ? (m.column ? v.length : rs.length) : m.agg === 'count_distinct' ? new Set(v).size
          : !v.length ? null : m.agg === 'sum' ? s : m.agg === 'avg' ? s / v.length : m.agg === 'min' ? Math.min(...v) : Math.max(...v);
        if (typeof o[name] === 'number') o[name] = Math.round(o[name] * 100) / 100;
      }
      return o;
    });
  }
  const ord = order_by || (time_bucket && (time_bucket.as || `${time_bucket.column}_${time_bucket.bucket}`)), dsc = order_by ? desc : false;
  if (ord) out.sort((a, b) => (dsc ? -1 : 1) * (a[ord] > b[ord] ? 1 : a[ord] < b[ord] ? -1 : 0));
  const raw = !group_by.length && !metrics.length, lim = raw ? Math.min(limit, 15) : Math.min(limit, 200);
  return { rowCount: out.length, truncated: out.length > lim, ...(raw ? { note: 'Raw sample rows only. To count, sum or average use group_by + metrics instead of fetching rows.' } : {}), rows: out.slice(0, lim) };
}

/* ---------------- Power BI dataset (optional) ---------------- */
const PBI = ['PBI_TENANT_ID', 'PBI_CLIENT_ID', 'PBI_CLIENT_SECRET', 'PBI_DATASET_ID'].every(k => P[k]);
let tok = { v: null, exp: 0 };
async function pbiToken() {
  if (tok.v && Date.now() < tok.exp) return tok.v;
  const r = await fetch(`https://login.microsoftonline.com/${P.PBI_TENANT_ID}/oauth2/v2.0/token`, {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'client_credentials', client_id: P.PBI_CLIENT_ID, client_secret: P.PBI_CLIENT_SECRET, scope: 'https://analysis.windows.net/powerbi/api/.default' }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error_description || 'Power BI sign-in failed');
  tok = { v: j.access_token, exp: Date.now() + (j.expires_in - 60) * 1000 };
  return tok.v;
}
async function runDax(query) {
  if (!/^\s*(DEFINE|EVALUATE)\b/i.test(query)) return { error: 'Only read-only DEFINE/EVALUATE queries are allowed.' };
  const base = P.PBI_WORKSPACE_ID ? `groups/${P.PBI_WORKSPACE_ID}/` : '';
  const r = await fetch(`https://api.powerbi.com/v1.0/myorg/${base}datasets/${P.PBI_DATASET_ID}/executeQueries`, {
    method: 'POST', headers: { Authorization: `Bearer ${await pbiToken()}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ queries: [{ query }], serializerSettings: { includeNulls: true } }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) return { error: j.error?.message || `Power BI error ${r.status}` };
  const rows = j.results?.[0]?.tables?.[0]?.rows || [];
  return { rowCount: rows.length, truncated: rows.length > 200, rows: rows.slice(0, 200) };
}

/* ---------------- Tools the agent can call ---------------- */
const TOOLS = [
  { name: 'list_tables', description: 'Describe the available data: tables, columns, types, sample rows (and Power BI tables/measures when connected). Call this first if unsure of the schema.', input_schema: { type: 'object', properties: { note: { type: 'string', description: 'Optional, unused' } } } },
  { name: 'make_chart', description: 'Show a bar or line chart to the user. Call after fetching data when a visual helps (comparisons, trends). Keep to <= 24 labels.', input_schema: { type: 'object', properties: { type: { type: 'string', enum: ['bar', 'line'] }, title: { type: 'string' }, labels: { type: 'array', items: { type: 'string' } }, series: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, values: { type: 'array', items: { type: 'number' } } }, required: ['name', 'values'] } } }, required: ['type', 'title', 'labels', 'series'] } },
];
TOOLS.push({ name: 'save_memory', description: 'Save a short fact or preference about the user to long-term memory.', input_schema: { type: 'object', properties: { fact: { type: 'string' } }, required: ['fact'] } });
TOOLS.push({
  name: 'query_data', description: 'Filter, group and aggregate a CSV table. Returns rows (limit up to 200). For totals/averages/counts use group_by + metrics; count_distinct gives unique counts (e.g. patients from an id column); time_bucket gives monthly/yearly trends; use order_by/limit for top-N.',
  input_schema: { type: 'object', properties: {
    table: { type: 'string' }, select: { type: 'array', items: { type: 'string' }, description: 'Columns for raw rows (no aggregation)' },
    filters: { type: 'array', items: { type: 'object', properties: { column: { type: 'string' }, op: { type: 'string', enum: Object.keys(OPS) }, value: { type: 'string', description: 'Value to compare. Numbers as text. For op "in" use a comma-separated list.' } }, required: ['column', 'op', 'value'] } },
    group_by: { type: 'array', items: { type: 'string' } },
    time_bucket: { type: 'object', description: 'Group by a date column bucket, for monthly/quarterly/yearly/daily trends. column must be a date-type column.', properties: { column: { type: 'string' }, bucket: { type: 'string', enum: ['year', 'quarter', 'month', 'day', 'weekday', 'hour'] }, as: { type: 'string' } }, required: ['column', 'bucket'] },
    metrics: { type: 'array', items: { type: 'object', properties: { column: { type: 'string' }, agg: { type: 'string', enum: ['sum', 'avg', 'min', 'max', 'count', 'count_distinct'] }, as: { type: 'string' } }, required: ['agg'] } },
    order_by: { type: 'string', description: 'A group_by column or metric alias' }, desc: { type: 'boolean' }, limit: { type: 'integer' } }, required: ['table'] },
});
if (PBI) TOOLS.push({ name: 'run_dax', description: 'Run a read-only DAX query (must start with EVALUATE or DEFINE) against the connected Power BI dataset. Max 200 rows returned; aggregate in DAX.', input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } });

const FORM = createFormulas(path.join(dir, 'formulas.json'), { bucketOf });

/* ---------------- Live SQL Server mode (one module) ---------------- */
const MODULE_FILE = P.MODULE_CONFIG || path.join(__dirname, 'module.config.json');
const SQL_MODE = !!((P.SQL_SERVER || P.SQL_MOCK) && fs.existsSync(MODULE_FILE));
if ((P.SQL_SERVER || P.SQL_MOCK) && !SQL_MODE) console.error(`SQL_SERVER is set but ${MODULE_FILE} was not found: copy module.config.example.json to module.config.json and edit it.`);
let SQLRT = null, SQLTEXT = '', MODCFG = null, ROWS = { t: 0, n: 0 };
if (SQL_MODE) {
  MODCFG = loadModule(MODULE_FILE);
  SQLRT = createSqlRuntime(MODCFG, P.SQL_MOCK ? mockExecutor(MODCFG) : await makeExecutor(P));
  SQLTEXT = SQLRT.info();
  TOOLS.splice(0, TOOLS.length, ...TOOLS.filter(t => ['make_chart', 'save_memory'].includes(t.name)), ...SQLRT.tools);
}
const sqlRows = async () => { if (Date.now() - ROWS.t > 300000) { try { ROWS = { t: Date.now(), n: await SQLRT.rowCount() }; } catch { ROWS = { t: Date.now() - 240000, n: 0 }; } } return ROWS.n; };

async function runTool(name, input, send) {
  if (SQL_MODE && ['query_kpi', 'get_values', 'run_sql'].includes(name)) return SQLRT.run(name, input);
  if (name === 'query_measures') return FORM.run(input, TABLES);
  if (name === 'query_data') return queryData(input);
  if (name === 'run_dax') return runDax(input.query);
  if (name === 'save_memory') { send('memory', { fact: String(input.fact).slice(0, 200) }); return { ok: 'Saved to memory.' }; }
  if (name === 'make_chart') { send('chart', { chart: input }); return { ok: 'Chart displayed to the user.' }; }
  if (name === 'list_tables') {
    const out = { csv_tables: Object.fromEntries(Object.entries(TABLES).map(([k, t]) => [k, { rowCount: t.rows.length, columns: t.types, sample: t.rows.slice(0, 3) }])) };
    if (PBI) for (const [k, q] of [['pbi_columns', 'EVALUATE INFO.VIEW.COLUMNS()'], ['pbi_measures', 'EVALUATE INFO.VIEW.MEASURES()']]) out[k] = await runDax(q).catch(e => ({ error: e.message }));
    return out;
  }
  return { error: 'Unknown tool' };
}

const SYSTEM = (lang, custom) => `You are a data analyst assistant embedded next to a Power BI report. Answer questions using the user's data only.
Rules:
- Always fetch numbers with tools; never guess or estimate figures. If the data cannot answer, say so plainly.
- The schema is listed below, so do NOT call list_tables. Be fast: use as few tool calls as possible, usually ONE query_data with group_by/metrics/time_bucket. Never fetch raw rows to count, sum or average.
- If a term is ambiguous (e.g. "pat count"), pick the most sensible column, state that assumption in one short sentence, and answer; ask only if nothing fits.
- Use make_chart for comparisons or trends (one chart per answer unless asked).
- LANGUAGE: ${lang && lang !== 'auto' ? `Reply ONLY in ${lang}, even if the user writes in another language. Translate everything: sentences, headings, chart titles and labels.` : "Reply in the same language the user's latest message is written in (English if English)."} Write the whole reply, including chart titles and labels, in that language and script. Keep numbers as digits and keep column/table names exactly as they appear in the data.
- Answers may be read aloud: be concise, lead with the answer, give units, avoid long lists (top 5 at most unless asked).
- Today is ${new Date().toISOString().slice(0, 10)}.
- If the user says "remember ..." or shares a lasting preference, call save_memory. You can read attached images and text files; explain, summarise, write code or answer general questions like a normal assistant, and use the data tools only for questions about the loaded data.
${custom ? `\nUser's custom instructions and saved memory (follow them):\n${String(custom).slice(0, 4000)}` : ''}
\nLoaded tables (use these exact names):\n${SQL_MODE ? SQLTEXT : tablesInfo() + FORM.info(TABLES)}\n${schemaNotes ? `\nBusiness notes about the data:\n${schemaNotes}` : ''}`;

const SCRIPT_LANGS = [[/[\u0B80-\u0BFF]/, 'Tamil'], [/[\u0900-\u097F]/, 'Hindi'], [/[\u0C00-\u0C7F]/, 'Telugu'], [/[\u0C80-\u0CFF]/, 'Kannada'], [/[\u0D00-\u0D7F]/, 'Malayalam'], [/[\u0980-\u09FF]/, 'Bengali'], [/[\u0A80-\u0AFF]/, 'Gujarati'], [/[\u0A00-\u0A7F]/, 'Punjabi'], [/[\u0600-\u06FF]/, 'Arabic']];
const detectLang = t => (SCRIPT_LANGS.find(([r]) => r.test(t)) || [])[1];
const lastUserText = ms => { const m = [...(ms || [])].reverse().find(x => x.role === 'user'); const c = m && m.content; return Array.isArray(c) ? c.map(p => p.text || '').join(' ') : String(c || ''); };
/* ---------------- Chat endpoint (SSE) + per-request usage tracking ---------------- */
const oaiTools = () => [...TOOLS, ...(!SQL_MODE && FORM.hasAny(TABLES) ? [FORM.toolDef(TABLES)] : [])].map(t => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.input_schema } }));
const LOG_FILE = P.LOG_FILE || path.join(__dirname, 'logs', 'requests.jsonl');
fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
const LOG_CONTENT = P.LOG_CONTENT !== 'false'; // false = log only sizes, not questions/answers (privacy)
const estTokens = x => Math.ceil(String(x || '').length / 4);
const nf = x => Number(x || 0).toLocaleString('en-US');
const clip = (x, m) => { x = String(x || '').replace(/\s+/g, ' ').trim(); return x.length > m ? x.slice(0, m - 1) + '…' : x; };
let CANDS = null;
async function candidates() {
  if (P.MODEL) return [P.MODEL];
  if (PROVIDER !== 'gemini') return [MODEL, ...(PROVIDER === 'groq' ? ['llama-3.1-8b-instant'] : [])];
  if (CANDS) return CANDS;
  let ids = [];
  try { const j = await (await fetch(`${BASE}/models`, { headers: { Authorization: `Bearer ${KEY}` }, signal: AbortSignal.timeout(6000) })).json(); ids = (j.data || []).map(m => String(m.id).replace(/^models\//, '')).filter(id => /^gemini-[\d.]+-flash(-lite)?$/.test(id)); } catch { /* use preset */ }
  const ver = id => id.match(/[\d.]+/)[0], cmp = (a, b) => ver(b).localeCompare(ver(a), undefined, { numeric: true });
  const c = [...ids.filter(i => /lite$/.test(i)).sort(cmp).slice(0, 2), ...ids.filter(i => !/lite$/.test(i)).sort(cmp).slice(0, 2)]; // lite = fastest, tried first
  return (CANDS = c.length ? c : [MODEL, 'gemini-2.5-flash']);
}
const BAD = new Map(), CACHE = new Map(), CACHE_TTL = SQL_MODE ? 120000 : 1800000; // live data: keep cached answers only 2 minutes
let LAST_GOOD = null, NO_RSN = false;
const order = c => { const now = Date.now(), ok = c.filter(m => !(BAD.get(m) > now)), bad = c.filter(m => BAD.get(m) > now); return [...(LAST_GOOD && ok.includes(LAST_GOOD) ? [LAST_GOOD, ...ok.filter(m => m !== LAST_GOOD)] : ok), ...bad]; };
function compact(out) { // fewer tokens: rows as arrays, max 60 rows
  if (out && out.sql) { const { sql, ...rest } = out; out = rest; }
  if (!out || !Array.isArray(out.rows) || !out.rows.length || Array.isArray(out.rows[0]) || typeof out.rows[0] !== 'object') return out;
  const cols = Object.keys(out.rows[0]), rows = out.rows.slice(0, 60);
  return { ...out, truncated: out.truncated || out.rows.length > 60, columns: cols, rows: rows.map(r => cols.map(c => r[c])) };
}
function printRequest(r, no) {
  const w = 96, L = (k, v) => `│ ${k.padEnd(9)}: ${v}`;
  console.log(['', `┌─ REQUEST #${no}  ${r.ts.replace('T', ' ').slice(0, 19)} UTC ` + '─'.repeat(w - 38),
    L('User', r.user || '-'), L('Question', clip(r.question, 80)), L('Answer', clip(r.answer || r.error, 80)),
    L('Model', `${r.models.join(', ') || '-'}  (provider: ${r.provider}${r.failed_attempts ? `, ${r.failed_attempts} failed attempt(s)${r.status === 'ok' ? ' before success' : ''}` : ''})`),
    L('Tokens', `${nf(r.total_tokens)} total  = ${nf(r.prompt_tokens)} prompt + ${nf(r.completion_tokens)} completion${r.estimated ? '  (estimated)' : ''}   AI calls: ${r.llm_calls}`),
    L('Data', r.tools.length ? r.tools.map(t => `${t.name}${t.rows != null ? ` (${t.rows} rows)` : ''}${t.ok ? '' : ' [failed]'}`).join(', ') : 'no data tool used'),
    ...r.tools.filter(t => t.sql).slice(0, 3).map(t => L('Query', clip(t.sql, 84))),
    L('Time', `${(r.latency_ms / 1000).toFixed(1)} s     Status: ${r.status.toUpperCase()}${r.error ? '  ' + clip(r.error, 60) : ''}`), '└' + '─'.repeat(w - 1)].join('\n'));
}
let reqNo = 0;
app.post('/api/chat', async (req, res) => {
  const t0 = Date.now(), q = lastUserText(req.body.messages);
  const rec = { id: t0.toString(36) + Math.random().toString(36).slice(2, 5), ts: new Date().toISOString(), provider: PROVIDER, user: req.user?.username, language: (req.body.lang && req.body.lang !== 'auto') ? String(req.body.lang).slice(0, 30) : (detectLang(q) || 'auto'), question: q.slice(0, 20000), answer: '', calls: [], tools: [], charts: [], status: 'ok', error: null };
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  const send = (type, data = {}) => res.write(`data: ${JSON.stringify({ type, ...data })}\n\n`);
  const msgs = [{ role: 'system', content: SYSTEM(rec.language, req.body.custom) }, ...(req.body.messages || []).slice(-20).map(m => ({ role: m.role, content: Array.isArray(m.content) ? m.content : String(m.content) }))];
  const single = (req.body.messages || []).length === 1 && !req.body.custom && typeof req.body.messages[0].content === 'string';
  const ckey = single ? [PROVIDER, rec.language, 'f' + FORM.version, Object.entries(TABLES).map(([k, t]) => k + ':' + t.rows.length).join(','), q.toLowerCase().replace(/\s+/g, ' ').trim()].join('|') : null;
  const hit = ckey && CACHE.get(ckey) && Date.now() - CACHE.get(ckey).t < CACHE_TTL ? CACHE.get(ckey) : null;
  if (hit) { // same question asked before: answer instantly, 0 tokens
    rec.cached = true; rec.answer = hit.answer;
    hit.charts.forEach(c => send('chart', { chart: c }));
    send('text', { text: hit.answer });
  } else try {
    if (!KEY && PROVIDER !== 'ollama' && !P.LLM_API_KEY) throw new Error(`No API key. Add ${PROVIDER.toUpperCase()}_API_KEY to .env (free), or set PROVIDER=ollama.`);
    const cands = await candidates(), RETRY = [404, 429, 500, 502, 503, 504], zero = { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 };
    let empty = 0;
    const call = async () => {
      let last;
      const list = order(cands);
      for (let n = 0; n < list.length; n++) {
        const model = list[n], s = Date.now();
        try {
          const r = await fetch(`${BASE}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(KEY ? { Authorization: `Bearer ${KEY}` } : {}) }, body: JSON.stringify({ model, messages: msgs, tools: oaiTools(), tool_choice: 'auto', temperature: 0.2, ...(PROVIDER === 'gemini' && !NO_RSN ? { reasoning_effort: 'low' } : {}) }), signal: AbortSignal.timeout(25000) });
          const j = await r.json().catch(() => ({}));
          if (r.ok) {
            const u = j.usage || {}, m = j.choices?.[0]?.message || {}, est = u.prompt_tokens == null;
            const p = u.prompt_tokens ?? estTokens(JSON.stringify(msgs)), c = u.completion_tokens ?? estTokens((m.content || '') + JSON.stringify(m.tool_calls || ''));
            rec.calls.push({ model, ok: true, prompt_tokens: p, completion_tokens: c, total_tokens: u.total_tokens ?? p + c, reasoning_tokens: u.completion_tokens_details?.reasoning_tokens || 0, estimated: est, ms: Date.now() - s });
            LAST_GOOD = model; BAD.delete(model); return j;
          }
          const emsg = j.error?.message || j[0]?.error?.message || `Model error ${r.status}`;
          if (r.status === 400 && /reasoning|thinking/i.test(emsg) && !NO_RSN) { NO_RSN = true; n--; continue; } // model rejects the speed setting: retry without it
          rec.calls.push({ model, ok: false, http: r.status, ms: Date.now() - s, ...zero });
          last = new Error(emsg + ` [${model}]`); last.status = r.status;
          if (!RETRY.includes(r.status)) throw last;
          BAD.set(model, Date.now() + (r.status === 404 ? 30 : 5) * 60000); // skip this model for a while
        } catch (e) {
          if (e.status && !RETRY.includes(e.status)) throw e;
          if (!e.status) { rec.calls.push({ model, ok: false, http: 'timeout/network', ms: Date.now() - s, ...zero }); BAD.set(model, Date.now() + 5 * 60000); }
          last = e;
        }
      }
      throw last;
    };
    for (let i = 0; i < 8; i++) {
      const j = await call(), m = j.choices?.[0]?.message || {};
      const text = (m.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
      if (!text && !m.tool_calls?.length) {
        if (!empty++) { msgs.push({ role: 'user', content: 'Reply to my last message in plain text.' }); continue; }
        throw new Error(`The model returned an empty reply (finish_reason: ${j.choices?.[0]?.finish_reason || 'unknown'}). Try again.`);
      }
      msgs.push({ role: 'assistant', content: text, ...(m.tool_calls?.length ? { tool_calls: m.tool_calls } : {}) });
      if (text) { send('text', { text }); rec.answer += (rec.answer ? '\n\n' : '') + text; }
      if (!m.tool_calls?.length) break;
      if (text) send('text', { text: '\n\n' });
      for (const tc of m.tool_calls) {
        let args = {}, out;
        try { args = JSON.parse(tc.function.arguments || '{}'); } catch { /* bad JSON from model */ }
        send('tool', { name: tc.function.name });
        try { out = await runTool(tc.function.name, args, (t, d) => { if (t === 'chart') rec.charts.push(d.chart); send(t, d); }); } catch (e) { out = { error: e.message }; }
        rec.tools.push({ name: tc.function.name, args: JSON.stringify(args).slice(0, 300), ok: !out.error, rows: out.rowCount ?? null, ...(out.sql ? { sql: String(out.sql).slice(0, 1500) } : {}), ...(out.error ? { error: out.error } : {}) });
        msgs.push({ role: 'tool', tool_call_id: tc.id, name: tc.function.name, content: JSON.stringify(compact(out)).slice(0, 12000) });
      }
    }
  } catch (e) { rec.status = 'error'; rec.error = e.message; send('error', { message: e.message }); }
  const good = rec.calls.filter(c => c.ok), add = k => good.reduce((s, c) => s + (c[k] || 0), 0);
  Object.assign(rec, { latency_ms: Date.now() - t0, prompt_tokens: add('prompt_tokens'), completion_tokens: add('completion_tokens'), reasoning_tokens: add('reasoning_tokens'), total_tokens: add('total_tokens'), estimated: good.some(c => c.estimated), llm_calls: good.length, failed_attempts: rec.calls.length - good.length, models: [...new Set(good.map(c => c.model))] });
  if (rec.cached) rec.models = ['cache'];
  send('usage', { usage: { prompt_tokens: rec.prompt_tokens, completion_tokens: rec.completion_tokens, total_tokens: rec.total_tokens, calls: rec.llm_calls, ms: rec.latency_ms, model: rec.models.join(', '), estimated: rec.estimated } });
  send('done'); res.end();
  const charts = rec.charts; delete rec.charts;
  if (ckey && rec.status === 'ok' && rec.answer && !rec.cached) CACHE.set(ckey, { t: Date.now(), answer: rec.answer, charts });
  const saved = LOG_CONTENT ? rec : { ...rec, question: `[not stored: ${rec.question.length} chars]`, answer: `[not stored: ${rec.answer.length} chars]`, tools: rec.tools.map(t => ({ ...t, args: '[not stored]' })) };
  fs.appendFile(LOG_FILE, JSON.stringify(saved) + '\n', () => {});
  printRequest(saved, ++reqNo);
});

/* Data is loaded on the server (data/ folder or Power BI). Only an admin may change it. */
const canAdmin = req => !!(req.user && req.user.role === 'admin');
const guard = (req, res, next) => (SQL_MODE ? res.status(403).json({ error: 'Data comes from SQL Server in this deployment.' }) : canAdmin(req) ? next() : res.status(403).json({ error: 'Only the administrator can change the data.' }));
app.get('/api/status', async (req, res) => {
  let tables = Object.entries(TABLES).map(([name, t]) => ({ name, rows: t.rows.length, columns: t.cols }));
  if (SQL_MODE) tables = [{ name: (MODCFG.name || 'Module') + ' (live SQL Server)', rows: await sqlRows(), columns: Object.values(MODCFG.tables).flatMap(t => Object.keys(t.columns)) }];
  res.json({ provider: PROVIDER, model: MODEL, powerbi: PBI, sql: SQL_MODE, canUpload: canAdmin(req) && !SQL_MODE, tables });
});
app.get('/api/formulas', (req, res) => { const out = {}; for (const t of Object.keys(TABLES)) { const d = FORM.get(t); out[t] = { measures: d.measures, segments: d.segments, notes: d.notes }; } res.json({ tables: out }); });
app.get('/api/admin/schema', adminOnly, (req, res) => res.json({ sql: SQL_MODE, tables: Object.entries(TABLES).map(([name, t]) => ({ name, rows: t.rows.length, columns: t.cols.map(c => ({ name: c, type: t.types[c], samples: [...new Set(t.rows.slice(0, 3000).map(r => r[c]).filter(v => v != null && v !== ''))].slice(0, 40) })) })) }));
app.put('/api/admin/formulas/:table', adminOnly, (req, res) => { try { res.json(FORM.save(req.params.table, req.body, TABLES[req.params.table])); } catch (e) { res.status(400).json({ error: e.message }); } });
app.post('/api/admin/formulas/test', adminOnly, (req, res) => { const T = TABLES[req.body.table]; if (!T) return res.status(404).json({ ok: false, error: 'That dataset is not loaded.' }); res.json(FORM.test(req.body.kind, req.body.text, req.body.name, T, req.body.others)); });
/* Plain English -> formula (admin only). Uses the same AI provider; the result is validated and test-run before it is returned. */
app.post('/api/admin/formulas/from-english', adminOnly, async (req, res) => {
  try {
    const { table, kind = 'measure', text, name, others } = req.body || {}, T = TABLES[table];
    if (!T) return res.status(404).json({ ok: false, error: 'That dataset is not loaded.' });
    const english = String(text || '').trim(); if (!english) return res.status(400).json({ ok: false, error: 'Write the meaning in plain English first.' });
    const seg = kind === 'segment', sib = (others?.measures || []).filter(m => m.name && NORM_NAME(m.name) !== NORM_NAME(name || '')).map(m => `[${m.name}]`).join(', ');
    const cols = T.cols.map(c => `- '${table}'[${c}] (${T.types[c]}) e.g. ${[...new Set(T.rows.slice(0, 2000).map(r => r[c]).filter(v => v != null && v !== ''))].slice(0, 6).map(v => JSON.stringify(v)).join(', ')}`).join('\n');
    const sys = `You convert a plain-English business definition into ONE Power BI DAX-style ${seg ? 'filter condition (true/false per row)' : 'measure formula'}.
Supported: DISTINCTCOUNT, COUNT, COUNTROWS, SUM, AVERAGE, MIN, MAX, CALCULATE (with filters, FILTER, ALL), DIVIDE, IF, SWITCH, AND/OR/NOT, &&, ||, IN { }, ISBLANK, COALESCE, ROUND, ABS, YEAR, MONTH, DAY, TODAY, DATE, UPPER, LOWER, CONTAINSSTRING${seg ? '' : ', and references to other measures like [Total Tickets]'}.
Use only these columns of table '${table}', written as '${table}'[Column]:\n${cols}\n${!seg && sib ? 'Other measures you may reference: ' + sib + '\n' : ''}"Unique" or "without counting duplicates" means DISTINCTCOUNT. Match text values to the example values shown.
Reply with ONLY the formula on one line: no name, no "=" prefix, no explanation, no markdown.`;
    const clean = t => String(t || '').replace(/```[a-z]*/gi, '').replace(/`/g, '').trim().split('\n').map(x => x.trim()).filter(Boolean).join(' ');
    const model = (await candidates())[0];
    let msgs = [{ role: 'system', content: sys }, { role: 'user', content: (name ? `Name: ${name}\n` : '') + `Meaning: ${english}` }], last = null, formula = '';
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await fetch(`${BASE}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(KEY ? { Authorization: `Bearer ${KEY}` } : {}) }, body: JSON.stringify({ model, messages: msgs, temperature: 0 }), signal: AbortSignal.timeout(25000) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) return res.json({ ok: false, error: j.error?.message || j[0]?.error?.message || `The AI service returned ${r.status}. Write the formula yourself or try again.` });
      formula = clean(j.choices?.[0]?.message?.content);
      const m = formula.match(/^\s*\[?([^()'"{}=<>&|,+*\/]+?)\]?\s*=\s*(?=\S)/); if (!seg && m && !/^(IF|AND|OR|NOT)$/i.test(m[1].trim())) formula = formula.slice(m[0].length).trim();
      last = FORM.test(seg ? 'segment' : 'measure', formula, name, T, others || {});
      if (last.ok) break;
      msgs = [...msgs, { role: 'assistant', content: formula }, { role: 'user', content: `That formula fails: ${last.error}\nReturn a corrected formula only.` }];
    }
    res.json(last?.ok ? { ok: true, formula, ...last } : { ok: false, error: `Could not build a valid formula (${last?.error || 'unknown'}). Try rewording, or write it in DAX.` });
  } catch (e) { res.json({ ok: false, error: String(e.message).slice(0, 300) }); }
});
const NORM_NAME = x => String(x).toLowerCase().replace(/[\s_]+/g, '');
app.post('/api/upload', guard, (req, res) => {
  try {
    const name = safeName(req.body.name);
    registerTable(name, req.body.csv);
    res.json({ ok: true, name, rows: TABLES[name].rows.length, columns: TABLES[name].cols });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/table/:name', guard, (req, res) => {
  const n = safeName(req.params.name); delete TABLES[n];
  try { fs.unlinkSync(path.join(dir, n + '.csv')); } catch { /* not on disk */ }
  res.json({ ok: true });
});
await pickModel();
app.listen(P.PORT || 3000, () => console.log(`Data: ${SQL_MODE ? 'LIVE SQL Server module "' + MODCFG.name + '"' : 'CSV/other'}  ·  Usage log: ${LOG_FILE}  (content logging: ${LOG_CONTENT ? 'on' : 'off'})  ·  report: npm run report`) || console.log(`Data assistant on http://localhost:${P.PORT || 3000}  (${PROVIDER}/${MODEL}, tables: ${Object.keys(TABLES).join(', ') || 'none'}, powerbi: ${PBI})`));
