Table "sales": monthly sales per Region and Product. Sales = revenue, Profit = margin in currency, Units = quantity sold.
Replace this file and data/sales.csv with your own exported Power BI data (CSV) and notes on what columns mean.
