// Usage & cost report for the Data Assistant. Run:  npm run report   (see README for options)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const flag = n => args.includes('--' + n);
const opt = (n, d) => { const i = args.indexOf('--' + n); return i >= 0 && args[i + 1] ? args[i + 1] : d; };
const FILE = opt('file', process.env.LOG_FILE || path.join(__dirname, 'logs', 'requests.jsonl'));
if (!fs.existsSync(FILE)) { console.log(`No usage log found at ${FILE}.\nStart the app (npm start) and ask some questions first.`); process.exit(0); }
let recs = fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
const since = opt('since'), until = opt('until');
if (since) recs = recs.filter(r => r.ts.slice(0, 10) >= since);
if (until) recs = recs.filter(r => r.ts.slice(0, 10) <= until);
if (!recs.length) { console.log('No requests in the selected period.'); process.exit(0); }

const n = x => Number(x || 0).toLocaleString('en-US');
const sum = (a, k) => a.reduce((s, r) => s + (r[k] || 0), 0);
const trunc = (s, m) => { s = String(s || '').replace(/\s+/g, ' ').trim(); return s.length > m ? s.slice(0, m - 1) + '…' : s; };
const secs = ms => (ms / 1000).toFixed(1) + 's';
const pct = (a, p) => { const s = [...a].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))] || 0; };
const W = 100, bar = '═'.repeat(W), thin = '─'.repeat(W);
const title = t => console.log('\n' + t + '\n' + thin);
function table(head, rows, align = []) {
  const w = head.map((h, i) => Math.max(String(h).length, ...rows.map(r => String(r[i]).length)));
  const line = (l, m, r) => l + w.map(x => '─'.repeat(x + 2)).join(m) + r;
  const cell = (v, i) => ' ' + (align[i] === 'r' ? String(v).padStart(w[i]) : String(v).padEnd(w[i])) + ' ';
  return [line('┌', '┬', '┐'), '│' + head.map(cell).join('│') + '│', line('├', '┼', '┤'), ...rows.map(r => '│' + r.map(cell).join('│') + '│'), line('└', '┴', '┘')].join('\n');
}
const wrap = (s, w, ind) => String(s || '').split('\n').flatMap(p => { const o = []; let l = ''; for (const wd of p.split(/\s+/)) { if ((l + ' ' + wd).trim().length > w) { o.push(l); l = wd; } else l = (l + ' ' + wd).trim(); } o.push(l); return o; }).map(x => ind + x).join('\n');

/* pricing (optional). Edit pricing.json with your plan's current rates; null = free tier / unknown */
let pricing = { per_million_tokens: {} };
try { pricing = JSON.parse(fs.readFileSync(path.join(__dirname, 'pricing.json'), 'utf8')); } catch { /* none */ }
const rate = m => pricing.per_million_tokens[m] || pricing.per_million_tokens.default || {};
const callCost = c => { const r = rate(c.model); return r.input == null || r.output == null ? null : (c.prompt_tokens * r.input + c.completion_tokens * r.output) / 1e6; };
let priced = true;
recs.forEach(r => { const cs = (r.calls || []).filter(c => c.ok).map(callCost); r.cost = cs.some(x => x == null) || !cs.length ? null : cs.reduce((a, b) => a + b, 0); if (r.cost == null) priced = false; });
const cur = pricing.currency || 'USD', money = x => (x == null ? 'n/a' : cur + ' ' + x.toFixed(x < 1 ? 4 : 2));

const ok = recs.filter(r => r.status === 'ok'), tot = sum(recs, 'total_tokens');
const lat = recs.map(r => r.latency_ms || 0), toks = recs.map(r => r.total_tokens || 0);
const avgTok = tot / recs.length, dayOf = r => r.ts.slice(0, 10);
const days = [...new Set(recs.map(dayOf))].sort();
const totalCost = priced ? recs.reduce((s, r) => s + r.cost, 0) : null;

console.log('\n' + bar + '\n  DATA ASSISTANT: AI USAGE & COST REPORT\n' + bar);
if (opt('label')) console.log('  *** ' + opt('label') + ' ***');
console.log(`  Generated : ${new Date().toISOString().replace('T', ' ').slice(0, 19)} UTC`);
console.log(`  Period    : ${days[0]} to ${days[days.length - 1]}  (${days.length} day${days.length > 1 ? 's' : ''})`);
console.log(`  Provider  : ${[...new Set(recs.map(r => r.provider))].join(', ')}    Models: ${[...new Set(recs.flatMap(r => r.models || []))].join(', ') || 'n/a'}`);
console.log(`  Source    : ${FILE}`);

title('1. EXECUTIVE SUMMARY');
console.log(table(['Metric', 'Value'], [
  ['Total requests (questions asked)', n(recs.length)],
  ['  Successful / Failed', `${n(ok.length)} / ${n(recs.length - ok.length)}`],
  ['Total tokens consumed', n(tot)],
  ['  Prompt (input) tokens', n(sum(recs, 'prompt_tokens'))],
  ['  Completion (output) tokens', n(sum(recs, 'completion_tokens'))],
  ['Average tokens per request', n(Math.round(avgTok))],
  ['Median / 95th percentile / max tokens', `${n(pct(toks, .5))} / ${n(pct(toks, .95))} / ${n(Math.max(...toks))}`],
  ['AI calls made (incl. data-tool rounds)', n(sum(recs, 'llm_calls'))],
  ['Answered instantly from cache (0 tokens)', n(recs.filter(x => x.cached).length)],
  ['Failed AI attempts (busy / fallback)', n(sum(recs, 'failed_attempts'))],
  ['Average response time', secs(sum(recs, 'latency_ms') / recs.length) + `  (95th percentile ${secs(pct(lat, .95))})`],
  ['Estimated cost', priced ? money(totalCost) : 'Free tier / rates not set (see pricing.json)'],
], ['l', 'r']));
if (recs.some(r => r.estimated)) console.log('  Note: some token counts were estimated (provider returned no usage data): marked with ~ below.');

title('2. USAGE BY MODEL');
const byModel = {};
recs.forEach(r => (r.calls || []).forEach(c => { const m = byModel[c.model] ||= { calls: 0, fail: 0, p: 0, c: 0, ms: 0 }; c.ok ? (m.calls++, m.p += c.prompt_tokens, m.c += c.completion_tokens) : m.fail++; m.ms += c.ms || 0; }));
console.log(table(['Model', 'Calls', 'Failed', 'Prompt tok', 'Completion tok', 'Total tok', 'Avg ms/call'],
  Object.entries(byModel).map(([k, m]) => [k, n(m.calls), n(m.fail), n(m.p), n(m.c), n(m.p + m.c), n(Math.round(m.ms / ((m.calls + m.fail) || 1)))]), ['l', 'r', 'r', 'r', 'r', 'r', 'r']));

title('3. USAGE BY DAY');
console.log(table(['Date', 'Requests', 'Errors', 'Total tokens', 'Avg tokens/request', 'Cost'],
  days.map(d => { const a = recs.filter(r => dayOf(r) === d); return [d, n(a.length), n(a.filter(r => r.status !== 'ok').length), n(sum(a, 'total_tokens')), n(Math.round(sum(a, 'total_tokens') / a.length)), priced ? money(a.reduce((s, r) => s + r.cost, 0)) : 'n/a']; }), ['l', 'r', 'r', 'r', 'r', 'r']));

if (recs.some(r => r.user)) {
  title('3b. USAGE BY USER');
  const us = [...new Set(recs.map(r => r.user || '(unknown)'))];
  console.log(table(['User', 'Requests', 'Total tokens', 'Avg tokens/request'], us.map(u => { const a = recs.filter(r => (r.user || '(unknown)') === u); return [u, n(a.length), n(sum(a, 'total_tokens')), n(Math.round(sum(a, 'total_tokens') / a.length))]; }), ['l', 'r', 'r', 'r']));
}

title('4. TOP 5 MOST TOKEN-HEAVY REQUESTS');
console.log(table(['#', 'Time', 'Tokens', 'In', 'Out', 'Calls', 'Question'], [...recs].sort((a, b) => b.total_tokens - a.total_tokens).slice(0, 5).map(r => [r.id.slice(-5), r.ts.slice(5, 19).replace('T', ' '), n(r.total_tokens), n(r.prompt_tokens), n(r.completion_tokens), r.llm_calls, trunc(r.question, 44)]), ['l', 'l', 'r', 'r', 'r', 'r', 'l']));

title('5. EVERY REQUEST (question, tokens, time, status)');
console.log(table(['#', 'Time (UTC)', 'Status', 'Tokens', 'In', 'Out', 'Calls', 'Time', 'Model', 'Question'],
  recs.map((r, i) => [i + 1, r.ts.slice(5, 19).replace('T', ' '), r.status === 'ok' ? 'OK' : 'ERROR', (r.estimated ? '~' : '') + n(r.total_tokens), n(r.prompt_tokens), n(r.completion_tokens), r.llm_calls || 0, secs(r.latency_ms || 0), (r.models || []).join(',') || '-', trunc(r.question, 38)]),
  ['r', 'l', 'l', 'r', 'r', 'r', 'r', 'r', 'l', 'l']));

title('6. MONTHLY PROJECTION (based on the average tokens per request above)');
const users = +opt('users', 25), per = +opt('per-day', 10), wd = +opt('days', 22);
const sc = [['Pilot (low)', Math.max(1, Math.round(users / 5)), Math.max(1, Math.round(per / 2))], ['Expected', users, per], ['Heavy use', users * 3, per * 2]];
console.log(table(['Scenario', 'Users', 'Requests/user/day', 'Requests/month', 'Tokens/month', 'Cost/month'],
  sc.map(([s, u, p]) => { const rq = u * p * wd; return [s, n(u), n(p), n(rq), n(Math.round(rq * avgTok)), priced ? money(rq * (totalCost / recs.length)) : 'n/a']; }), ['l', 'r', 'r', 'r', 'r', 'r']));
console.log(`  Assumes ${wd} working days/month. Change with: --users ${users} --per-day ${per} --days ${wd}`);
console.log('  Free API tiers also have rate limits (requests/minute, tokens/day). Check your provider\'s quota page before roll-out.');

if (flag('full')) {
  title('7. APPENDIX: FULL QUESTIONS AND ANSWERS');
  recs.forEach((r, i) => {
    console.log(`\n[${i + 1}] ${r.ts.replace('T', ' ').slice(0, 19)} UTC · ${r.status.toUpperCase()} · ${n(r.total_tokens)} tokens (in ${n(r.prompt_tokens)} / out ${n(r.completion_tokens)}) · ${r.llm_calls} call(s) · ${secs(r.latency_ms || 0)} · ${(r.models || []).join(', ')}`);
    console.log('  QUESTION:\n' + wrap(r.question, 92, '    '));
    console.log('  ANSWER:\n' + wrap(r.answer || (r.error ? 'ERROR: ' + r.error : ''), 92, '    '));
    if (r.tools?.length) console.log('  DATA TOOLS USED: ' + r.tools.map(t => `${t.name}${t.rows != null ? ' (' + t.rows + ' rows)' : ''}${t.ok ? '' : ' [failed]'}`).join(', '));
    (r.tools || []).filter(t => t.sql).forEach(t => console.log('  QUERY / FORMULA USED:\n' + wrap(t.sql, 92, '    ')));
  });
}
console.log('\n' + thin + '\nAPPROVAL\n' + thin);
console.log('  Prepared by : ______________________   Date : ______________\n');
console.log('  Approved by : ______________________   Date : ______________   Signature : ______________');
console.log('  (Name / title)\n' + bar + '\n');

if (flag('csv')) {
  const esc = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const out = path.join(__dirname, 'reports', `usage-${new Date().toISOString().slice(0, 10)}.csv`);
  const head = ['id', 'timestamp', 'status', 'provider', 'models', 'language', 'llm_calls', 'failed_attempts', 'prompt_tokens', 'completion_tokens', 'total_tokens', 'latency_ms', 'estimated_cost', 'question', 'answer'];
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, '\uFEFF' + [head.join(','), ...recs.map(r => [r.id, r.ts, r.status, r.provider, (r.models || []).join('|'), r.language, r.llm_calls, r.failed_attempts, r.prompt_tokens, r.completion_tokens, r.total_tokens, r.latency_ms, r.cost ?? '', r.question, r.answer].map(esc).join(','))].join('\n'));
  console.log(`CSV exported: ${out}  (open in Excel)\n`);
}
