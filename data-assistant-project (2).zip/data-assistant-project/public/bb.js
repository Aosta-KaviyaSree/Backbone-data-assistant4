/* Backbone shared helpers: login token, API calls, toasts, modals */
const BB = (() => {
  const mem = {};
  const get = k => { try { return localStorage.getItem(k) || ''; } catch { return mem[k] || ''; } };
  const set = (k, v) => { try { v ? localStorage.setItem(k, v) : localStorage.removeItem(k); } catch { mem[k] = v; } };
  let akey = ''; try { akey = sessionStorage.getItem('ak') || ''; } catch { /* no session storage */ }
  const q = new URLSearchParams(location.search).get('key'); if (q) { akey = q; try { sessionStorage.setItem('ak', q); } catch { /* ignore */ } }
  const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  async function api(path, { method = 'GET', body } = {}) {
    const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(get('bb_token') ? { Authorization: 'Bearer ' + get('bb_token') } : {}), ...(akey ? { 'x-access-key': akey } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && j.auth) { set('bb_token', ''); if (!/login\.html/.test(location.pathname)) location.href = '/login.html?next=' + encodeURIComponent(location.pathname); }
    if (!r.ok) throw Object.assign(new Error(j.error || 'Error ' + r.status), { status: r.status });
    return j;
  }
  function toast(msg, type = '') { let t = document.getElementById('toasts'); if (!t) { t = document.createElement('div'); t.id = 'toasts'; document.body.appendChild(t); } const d = document.createElement('div'); d.className = 'toast ' + type; d.textContent = msg; t.appendChild(d); setTimeout(() => { d.style.transition = 'opacity .4s'; d.style.opacity = 0; setTimeout(() => d.remove(), 400); }, 3800); }
  function modal(html) { const o = document.createElement('div'); o.className = 'ov'; o.innerHTML = `<div class="mb">${html}</div>`; o.addEventListener('mousedown', e => { if (e.target === o) o.remove(); }); document.body.appendChild(o); return { el: o.firstChild, close: () => o.remove() }; }
  return { get, set, api, toast, modal, esc, logout() { set('bb_token', ''); location.href = '/login.html'; } };
})();
