# Deploy and link to Power BI

## 1. Host it (needs HTTPS and Node 18+)
- **Render (fastest)**: put the project in a PRIVATE GitHub repo, then Render > New > Blueprint (uses render.yaml). Set GEMINI_API_KEY, ACCESS_KEY, ADMIN_KEY when asked.
- **Azure App Service** (good if your hospital uses Microsoft): create a Linux Node 20 web app, deploy the folder (VS Code Azure extension or `az webapp up`), and add the variables below under Settings > Environment variables.
- **Any Docker host**: `docker build -t backbone . && docker run -p 3000:3000 --env-file .env backbone`

Environment variables: `PROVIDER=gemini`, `GEMINI_API_KEY`, `MODEL=gemini-3.5-flash-lite` (fast), `ACCESS_KEY` (required), `ADMIN_KEY` (optional), `LOG_CONTENT=false` (recommended for patient data).

Your link is then `https://YOUR-HOST/?key=ACCESS_KEY`.

## 2. Put it in Power BI
1. **Button (simplest, works everywhere)**: Power BI Desktop > Insert > Buttons > Blank. Format > Action > Type: *Web URL* > URL: `https://YOUR-HOST/?key=ACCESS_KEY`. Publish. Clicking opens the assistant in a new tab (microphone works).
2. **Report and assistant side by side**: in Power BI Service open the report > File > Embed report > **Website or portal** and copy the link (do NOT use "Publish to web": it is public). Then open `https://YOUR-HOST/portal.html?key=ACCESS_KEY&report=<URL-encoded embed link>` and give that URL to users, or add it to a Teams tab / SharePoint page.
3. **Microsoft Teams**: add the report as a tab, and add another tab of type Website with the assistant link.
Power BI has no built-in "web page" visual, which is why the button or portal page is used.

## 3. Data
Free hosts erase files on restart. Put your CSVs in `data/` before deploying (private repo only) so they load at start. Uploaded files and `logs/` are lost on restart unless you attach a persistent disk. Use only anonymised or synthetic patient data on a free host.

## 4. Security checklist
Set ACCESS_KEY, keep the repo private, use HTTPS only, keep `.env` out of git, rotate keys if leaked, and keep LOG_CONTENT=false. A shared key is basic protection; for production use single sign-on (e.g. Microsoft Entra ID) in front of the app.

## 5. Notes
Free tiers may sleep when idle (first request slower) and have API rate limits.

## 6. Inside your EXISTING Power BI report (custom visual + icon)
Files: `Backbone-Data-Assistant.pbiviz` (the visual) and `powerbi-visual/icons/` (blue icons, SVG + PNG).
1. On your host set `FRAME_ANCESTORS=*` and keep `ACCESS_KEY` set.
2. Power BI Desktop: open the report > Visualizations > **... (Get more visuals) > Import a visual from a file** > pick the .pbiviz.
3. Add the visual to a page. Format pane > **Assistant**: enter the Assistant URL (`https://YOUR-HOST`) and Access key.
4. Publish. In the Service your admin must allow custom visuals (tenant setting "Allow visuals created using the Power BI SDK"), or upload the file in Admin portal > Organizational visuals.

### Option A: a small blue icon tile
In Format > Assistant set **Display = Icon (opens in a new tab)**, set the label, and shrink the visual to about 90 x 90. Clicking it opens the assistant in a new tab (voice works there).

### Option B: icon that slides open a chat panel inside the report (bookmarks)
1. Add the visual (Display = Chat panel), size it as a tall panel (for example 420 x 620) at the right.
2. Insert > Image > `backbone-icon-128.png` and place it at the bottom-right. Insert another image `backbone-close-64.png` on the panel's top-right corner.
3. View > **Selection pane** and **Bookmarks pane**. Bookmark "Assistant OPEN": panel and close icon visible, open icon hidden. Bookmark "Assistant CLOSED": panel and close icon hidden, open icon visible. For both, untick **Data** in the bookmark options so filters are not reset.
4. Open icon > Format > Action > Type: Bookmark > "Assistant OPEN". Close icon > Action > Bookmark > "Assistant CLOSED". Select the "CLOSED" bookmark before publishing.

Notes: it is an uncertified visual. If your tenant or browser blocks embedding, the tile shows "Open in new tab". The microphone may be blocked inside a report; use the new-tab button for voice. To bake the URL into the file: edit `powerbi-visual/src/config.ts`, then `npm install` and `npm run package` in that folder.

## 7. Logins, formulas and Power BI
- The app now needs a login. Set `ADMIN_USER` and `ADMIN_PASSWORD` on the host before the first visit so nobody else can claim the admin account. `ACCESS_KEY` is optional extra protection.
- Point `DATA_DIR` at a persistent disk, otherwise formulas and accounts are lost when a free host restarts.
- Inside the Power BI visual the login page appears in the tile. Some browsers block saved logins inside embedded frames; if it keeps asking, use the visual's "Open in new tab".
- See ADMIN_GUIDE.md for formulas and users.
