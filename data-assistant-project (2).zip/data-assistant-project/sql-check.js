// npm run sql:check : verifies the connection, that every configured column exists, and runs each KPI formula once.
import 'dotenv/config';
import path from 'path';
import { fileURLToPath } from 'url';
import { loadModule, makeExecutor, mockExecutor, createSqlRuntime } from './sql.js';
const P = process.env, here = path.dirname(fileURLToPath(import.meta.url));
const file = P.MODULE_CONFIG || path.join(here, 'module.config.json');
let cfg;
try { cfg = loadModule(file); } catch (e) { console.log(`\n✗ Cannot load ${file}\n  ${e.message}\n  (copy module.config.example.json to module.config.json and edit it)`); process.exit(1); }
const exec = P.SQL_MOCK ? mockExecutor(cfg) : await makeExecutor(P);
const t0 = Date.now(), ok = '✓', bad = '✗';
console.log(`\nSQL CHECK: module "${cfg.name}"  server: ${P.SQL_MOCK ? '(mock)' : P.SQL_SERVER}  database: ${P.SQL_DATABASE || '-'}\n${'─'.repeat(86)}`);
let fails = 0;
for (const [tn, T] of Object.entries(cfg.tables)) {
  try {
    const n = Number((await exec(`SELECT COUNT_BIG(*) AS n FROM ${T.source}`, [], 1)).rows[0].n);
    console.log(`${ok} ${tn}: connected, ${n.toLocaleString()} rows in ${T.source}`);
    const parts = T.source.replace(/[\[\]]/g, '').split('.'), name = parts.pop(), schema = parts.pop() || 'dbo';
    const have = (await exec('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @p0 AND TABLE_NAME = @p1', [schema, name], 1000)).rows.map(r => r.COLUMN_NAME.toLowerCase());
    const missing = Object.keys(T.columns).filter(c => !have.includes(c.toLowerCase()));
    if (missing.length) { fails++; console.log(`${bad} ${tn}: columns in config but NOT in the database: ${missing.join(', ')}`); } else console.log(`${ok} ${tn}: all ${Object.keys(T.columns).length} configured columns exist`);
    const extra = have.filter(c => !Object.keys(T.columns).some(k => k.toLowerCase() === c));
    if (extra.length) console.log(`  i  ${extra.length} database columns are not described in the config (fine): ${extra.slice(0, 12).join(', ')}${extra.length > 12 ? '…' : ''}`);
  } catch (e) { fails++; console.log(`${bad} ${tn}: ${e.message}`); }
}
console.log('\nKPI formulas');
for (const [k, K] of Object.entries(cfg.kpis || {})) {
  const s = Date.now();
  try { const r = await exec(`SELECT ${K.expression} AS [v] FROM ${cfg.tables[K.table].source} AS t`, [], 1); console.log(`${ok} ${k.padEnd(22)} = ${String(Object.values(r.rows[0] || {})[0]).padEnd(16)} (${Date.now() - s} ms)  ${K.label || ''}`); }
  catch (e) { fails++; console.log(`${bad} ${k.padEnd(22)} ERROR: ${e.message.slice(0, 120)}`); }
}
const rt = createSqlRuntime(cfg, exec);
if ((cfg.examples || []).length) console.log('\nExample questions (tool call -> rows)');
for (const ex of cfg.examples || []) { const r = await rt.run('query_kpi', ex.call); console.log(`${r.error ? bad : ok} "${ex.q}" -> ${r.error ? r.error.slice(0, 100) : r.rowCount + ' row(s)'}`); if (r.error) fails++; }
console.log(`${'─'.repeat(86)}\n${fails ? bad + ' ' + fails + ' problem(s). Fix module.config.json or the view, then run again.' : ok + ' Everything checks out.'}  (${((Date.now() - t0) / 1000).toFixed(1)} s)\n`);
process.exit(fails ? 1 : 0);
