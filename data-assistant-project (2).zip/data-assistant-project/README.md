# Data Assistant: token-tracked AI chatbot (project)

Chat + voice + multilingual assistant over your data (CSV / Power BI), with **full per-request usage tracking** for approval and cost control.

## Run
1. `npm install`
2. `copy .env.example .env` (Windows) / `cp .env.example .env`, set `PROVIDER` and the free key (`GEMINI_API_KEY` or `GROQ_API_KEY`)
3. `npm start` then open http://localhost:3000
4. Upload your CSV/Excel in the app (localhost only), or put CSVs in `data/`

## What is recorded for every question
Question, answer, time, language, model(s) used, prompt/completion/total tokens (as reported by the provider; estimated and marked `~` if the provider gives none), AI calls (data-tool rounds), failed/busy attempts and fallbacks, data tools used (rows returned), latency, status/error.
- Live: a boxed summary prints in the console after each question; each answer shows its token line in the UI; the top bar shows tokens used today.
- Stored in `logs/requests.jsonl` (one JSON per request).

## Report for approval (console, printable)
```
npm run report              # executive summary, by model, by day, top 5, every request, projection, approval block
npm run report:full         # + appendix with full question and answer text
npm run report:csv          # + exports reports/usage-YYYY-MM-DD.csv (Excel)
npm run report -- --since 2026-11-01 --until 2026-11-30
npm run report -- --users 50 --per-day 15 --days 22     # change the monthly projection
```
Print to PDF: run the report in the terminal, copy the text (or `npm run report:full > reports/report.txt`), paste in Word/Notepad with a monospaced font (Consolas), print. A real example is in `examples/sample-report.txt` (mock numbers, clearly labelled).

## Cost
Free tiers cost nothing but have rate limits. To see a paid-equivalent estimate, put the provider's current per-million-token rates in `pricing.json`.

## Privacy (important for hospitals)
Logs contain questions and answers. Set `LOG_CONTENT=false` in `.env` to store only sizes and tokens, not text. Keep `logs/` access-restricted, and use only synthetic or anonymised data with free external AI services.

## Other settings
`ADMIN_KEY` (who may upload), `LOG_FILE`, `FRAME_ANCESTORS`, Power BI `PBI_*` (see `.env.example`).

## Language
The language box is authoritative: pick Tamil (or any language, including "Other language…") and every answer is in that language even if you type English. Leave it on Auto to get replies in the language you write in. Voice input and spoken replies follow the chosen language.

## Live SQL Server (one module) and Power BI icon
See `SQL_SETUP.md` (live data, your KPI formulas, `npm run sql:check`) and `DEPLOY.md` section 6 (the Power BI visual and blue icon).

## Logins, admin console and formulas
See `ADMIN_GUIDE.md`. Pages: `/login.html`, `/` (chat), `/admin.html` (admins only).
