// Live SQL Server access for ONE module, driven by module.config.json (tables, KPI formulas, rules).
// The AI never writes KPI formulas: it picks KPI names, and this file builds parameterised, read-only T-SQL from YOUR formulas.
import fs from 'fs';

const FORBIDDEN = /\b(insert|update|delete|drop|alter|create|truncate|exec|execute|merge|grant|revoke|deny|into|openrowset|openquery|opendatasource|waitfor|backup|restore|dbcc|bulk|shutdown|xp_\w+|sp_\w+)\b/i;
const norm = s => String(s).replace(/[\[\]"]/g, '').toLowerCase();

export function loadModule(file) {
  const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
  cfg.maxRows = Math.min(cfg.maxRows || 200, 500);
  cfg.fiscalStartMonth = cfg.fiscalStartMonth || 4;
  if (!cfg.tables || !Object.keys(cfg.tables).length) throw new Error('module config: "tables" is empty');
  for (const [tn, T] of Object.entries(cfg.tables)) {
    if (!/^[\w.\[\] ]+$/.test(T.source || '')) throw new Error(`tables.${tn}.source is missing or looks unsafe`);
    T.columns = T.columns || {};
    for (const c of Object.keys(T.columns)) if (!/^[\w ]+$/.test(c)) throw new Error(`Bad column name "${c}" in ${tn}`);
    if (T.dateColumn && !T.columns[T.dateColumn]) throw new Error(`tables.${tn}.dateColumn "${T.dateColumn}" is not in its columns`);
  }
  for (const [k, K] of Object.entries(cfg.kpis || {})) {
    K.table = K.table || Object.keys(cfg.tables)[0];
    if (!cfg.tables[K.table]) throw new Error(`kpis.${k}.table "${K.table}" does not exist`);
    if (!K.expression || /;|--|\/\*/.test(K.expression) || FORBIDDEN.test(K.expression)) throw new Error(`kpis.${k}.expression is empty or contains forbidden SQL`);
  }
  return cfg;
}

export function bucketExpr(c, b, fm = 4) {
  const fy = `(YEAR(${c}) - CASE WHEN MONTH(${c}) >= ${fm} THEN 0 ELSE 1 END)`;
  const fyLabel = fm === 1 ? `CONCAT('FY', ${fy})` : `CONCAT('FY', RIGHT(CAST(${fy} AS varchar(4)), 2), '-', RIGHT(CAST(${fy} + 1 AS varchar(4)), 2))`;
  const map = {
    year: `CAST(YEAR(${c}) AS char(4))`, quarter: `CONCAT(YEAR(${c}), '-Q', DATEPART(quarter, ${c}))`, month: `CONVERT(char(7), ${c}, 120)`,
    day: `CONVERT(char(10), ${c}, 120)`, weekday: `DATENAME(weekday, ${c})`, hour: `DATEPART(hour, ${c})`,
    fy: fyLabel, fyq: `CONCAT(${fyLabel}, ' Q', ((MONTH(${c}) - ${fm} + 12) % 12) / 3 + 1)`,
  };
  if (!map[b]) throw new Error(`Unknown time bucket "${b}". Use: ${Object.keys(map).join(', ')}`);
  return map[b];
}

export function buildKpiQuery(cfg, a) {
  const tn = a.table || Object.keys(cfg.tables)[0], T = cfg.tables[tn];
  if (!T) throw new Error(`Unknown table "${tn}". Tables: ${Object.keys(cfg.tables).join(', ')}`);
  const names = [].concat(a.kpis || []);
  if (!names.length) throw new Error(`Pass at least one KPI. Available: ${Object.keys(cfg.kpis).join(', ')}`);
  const params = [], P = v => (params.push(v), '@p' + (params.length - 1));
  const col = c => { if (!T.columns[c]) throw new Error(`Unknown column "${c}" in ${tn}. Columns: ${Object.keys(T.columns).join(', ')}`); return `t.[${c}]`; };
  const sel = [], grp = [], where = [], order = [];
  for (const d of a.group_by || []) { sel.push(`${col(d)} AS [${d}]`); grp.push(col(d)); }
  let bucketAlias = null;
  if (a.time_bucket) {
    const dc = a.time_bucket.column || T.dateColumn;
    if (!dc) throw new Error(`${tn} has no dateColumn; pass time_bucket.column`);
    bucketAlias = `${dc}_${a.time_bucket.bucket}`;
    const e = bucketExpr(col(dc), a.time_bucket.bucket, cfg.fiscalStartMonth);
    sel.push(`${e} AS [${bucketAlias}]`); grp.push(e);
    if (!a.order_by) order.push(`[${bucketAlias}] ASC`);
  }
  for (const k of names) {
    const K = cfg.kpis[k];
    if (!K) throw new Error(`Unknown KPI "${k}". Available: ${Object.keys(cfg.kpis).join(', ')}`);
    if (K.table !== tn) throw new Error(`KPI "${k}" belongs to table ${K.table}, not ${tn}`);
    sel.push(`${K.expression} AS [${k}]`);
  }
  if (a.date_from || a.date_to) {
    const dc = T.dateColumn; if (!dc) throw new Error(`${tn} has no dateColumn`);
    if (a.date_from) where.push(`t.[${dc}] >= ${P(a.date_from)}`);
    if (a.date_to) where.push(`t.[${dc}] < DATEADD(day, 1, ${P(a.date_to)})`);
  }
  for (const f of a.filters || []) {
    const c = col(f.column), ty = T.columns[f.column].type, cast = v => (ty === 'number' ? Number(v) : String(v));
    if (f.op === 'in') where.push(`${c} IN (${String(f.value).split(',').map(x => P(cast(x.trim()))).join(', ')})`);
    else if (f.op === 'contains') where.push(`${c} LIKE ${P('%' + String(f.value).replace(/[\\%_\[]/g, '\\$&') + '%')} ESCAPE '\\'`);
    else if (['=', '!=', '>', '<', '>=', '<='].includes(f.op)) where.push(`${c} ${f.op === '!=' ? '<>' : f.op} ${P(cast(f.value))}`);
    else throw new Error(`Unsupported filter operator "${f.op}"`);
  }
  if (a.order_by) {
    if (![...names, ...(a.group_by || []), bucketAlias].includes(a.order_by)) throw new Error(`order_by must be a KPI, group_by column or the time bucket`);
    order.push(`[${a.order_by}] ${a.desc === false ? 'ASC' : 'DESC'}`);
  } else if (!order.length) order.push(`[${names[0]}] DESC`);
  const limit = Math.max(1, Math.min(Number(a.limit) || 50, cfg.maxRows));
  const sql = `SELECT TOP (${limit}) ${sel.join(', ')} FROM ${T.source} AS t${where.length ? ' WHERE ' + where.join(' AND ') : ''}${grp.length ? ' GROUP BY ' + grp.join(', ') : ''} ORDER BY ${order.join(', ')}`;
  return { sql, params, limit };
}

export function validateSql(cfg, text) {
  const s = String(text || '').trim().replace(/;+\s*$/, '');
  if (!s) throw new Error('Empty query');
  const clean = s.replace(/'([^']|'')*'/g, "''").replace(/--.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '');
  if (clean.includes(';')) throw new Error('Only a single statement is allowed');
  if (!/^(select|with)\b/i.test(clean.trim())) throw new Error('Only SELECT queries are allowed');
  if (FORBIDDEN.test(clean)) throw new Error('Query contains a forbidden keyword (read-only SELECT only)');
  const allowed = Object.values(cfg.tables).map(t => norm(t.source));
  const ctes = [...clean.matchAll(/\b(\w+)\s+as\s*\(/gi)].map(m => m[1].toLowerCase());
  for (const m of clean.matchAll(/\b(?:from|join)\s+([\[\]\w."]+)/gi)) {
    const r = norm(m[1]);
    if (!allowed.some(a => a === r || a === 'dbo.' + r || a.endsWith('.' + r)) && !ctes.includes(r)) throw new Error(`Table "${m[1]}" is not allowed. Allowed: ${Object.values(cfg.tables).map(t => t.source).join(', ')}`);
  }
  return s;
}

const cl = (n, d) => Math.max(1, Math.min(Number(n) || d, 200));
export function sqlToolDefs(cfg) {
  const kpiNames = Object.keys(cfg.kpis || {}), tNames = Object.keys(cfg.tables);
  const defs = [
    { name: 'query_kpi', description: `Run KPI formulas from the module config on live SQL Server, optionally grouped. Use this for every number. KPIs: ${kpiNames.join(', ')}. time_bucket: year, quarter, month, day, weekday, hour, fy (financial year, e.g. FY24-25), fyq (financial quarter, e.g. FY24-25 Q3). Dates are yyyy-mm-dd.`,
      input_schema: { type: 'object', properties: {
        table: { type: 'string', enum: tNames }, kpis: { type: 'array', items: { type: 'string', enum: kpiNames } },
        group_by: { type: 'array', items: { type: 'string' }, description: 'Dimension columns' },
        time_bucket: { type: 'object', properties: { column: { type: 'string' }, bucket: { type: 'string', enum: ['year', 'quarter', 'month', 'day', 'weekday', 'hour', 'fy', 'fyq'] } }, required: ['bucket'] },
        date_from: { type: 'string' }, date_to: { type: 'string', description: 'Inclusive, yyyy-mm-dd' },
        filters: { type: 'array', items: { type: 'object', properties: { column: { type: 'string' }, op: { type: 'string', enum: ['=', '!=', '>', '<', '>=', '<=', 'contains', 'in'] }, value: { type: 'string', description: 'For op "in" use a comma-separated list' } }, required: ['column', 'op', 'value'] } },
        order_by: { type: 'string' }, desc: { type: 'boolean' }, limit: { type: 'integer' } }, required: ['kpis'] } },
    { name: 'get_values', description: 'List distinct values of a column (optionally matching a search text). Use it to find the exact spelling before filtering (e.g. department or doctor names).',
      input_schema: { type: 'object', properties: { table: { type: 'string', enum: tNames }, column: { type: 'string' }, search: { type: 'string' }, limit: { type: 'integer' } }, required: ['column'] } },
  ];
  if (cfg.allowAdHocSql) defs.push({ name: 'run_sql', description: `Last resort: a single read-only T-SQL SELECT on the allowed sources only (${Object.values(cfg.tables).map(t => t.source).join(', ')}). Max ${cfg.maxRows} rows. Prefer query_kpi.`, input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } });
  return defs;
}

export function sqlInfo(cfg) {
  const L = [`DATA SOURCE: live SQL Server, module "${cfg.name || 'module'}"${cfg.description ? ': ' + cfg.description : ''}. Tools: query_kpi (all numbers), get_values (exact names)${cfg.allowAdHocSql ? ', run_sql (last resort)' : ''}. Never invent formulas or numbers.`, 'Tables:'];
  for (const [tn, T] of Object.entries(cfg.tables)) {
    L.push(`- ${tn}${T.description ? ' (' + T.description + ')' : ''}${T.dateColumn ? '; date column: ' + T.dateColumn : ''}`);
    L.push('  columns: ' + Object.entries(T.columns).map(([c, d]) => `${c} [${d.type || 'text'}]${d.description ? ' ' + d.description : ''}`).join('; '));
  }
  L.push('KPIs (pass these names to query_kpi):');
  for (const [k, K] of Object.entries(cfg.kpis || {})) L.push(`- ${k}: ${K.label || k}${K.description ? '. ' + K.description : ''}  [formula: ${K.expression}]`);
  L.push(`Financial year starts in month ${cfg.fiscalStartMonth} (time_bucket fy / fyq).`);
  (cfg.rules || []).forEach(r => L.push('Rule: ' + r));
  if ((cfg.examples || []).length) { L.push('Examples:'); cfg.examples.forEach(e => L.push(`- "${e.q}" -> query_kpi ${JSON.stringify(e.call)}`)); }
  return L.join('\n');
}

export function createSqlRuntime(cfg, exec) {
  const clean = rows => rows.map(r => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, typeof v === 'bigint' ? Number(v) : v])));
  return {
    tools: sqlToolDefs(cfg),
    info: () => sqlInfo(cfg),
    async rowCount() { const T = Object.values(cfg.tables)[0]; const r = await exec(`SELECT COUNT_BIG(*) AS n FROM ${T.source}`, [], 1); return Number(r.rows[0].n); },
    async run(name, a) {
      try {
        if (name === 'query_kpi') { const q = buildKpiQuery(cfg, a), r = await exec(q.sql, q.params, q.limit); return { sql: q.sql, rowCount: r.rows.length, truncated: r.truncated, rows: clean(r.rows) }; }
        if (name === 'get_values') {
          const tn = a.table || Object.keys(cfg.tables)[0], T = cfg.tables[tn];
          if (!T || !T.columns[a.column]) throw new Error(`Unknown table/column. Columns of ${tn}: ${T ? Object.keys(T.columns).join(', ') : '-'}`);
          const lim = cl(a.limit, 30), params = [];
          if (a.search) params.push('%' + String(a.search).replace(/[\\%_\[]/g, '\\$&') + '%');
          const sql = `SELECT DISTINCT TOP (${lim}) t.[${a.column}] AS [value] FROM ${T.source} AS t WHERE t.[${a.column}] IS NOT NULL${a.search ? ` AND CAST(t.[${a.column}] AS nvarchar(200)) LIKE @p0 ESCAPE '\\'` : ''} ORDER BY 1`;
          const r = await exec(sql, params, lim); return { sql, rowCount: r.rows.length, values: r.rows.map(x => x.value) };
        }
        if (name === 'run_sql') { if (!cfg.allowAdHocSql) throw new Error('Ad-hoc SQL is disabled'); const s = validateSql(cfg, a.query), r = await exec(s, [], cfg.maxRows); return { sql: s, rowCount: r.rows.length, truncated: r.truncated, rows: clean(r.rows) }; }
        throw new Error('Unknown SQL tool');
      } catch (e) { return { error: String(e.message || e).slice(0, 400) }; }
    },
  };
}

/* real connection (mssql). Credentials come from .env; use a READ-ONLY login. */
export async function makeExecutor(env) {
  const sql = (await import('mssql')).default;
  let pool = null;
  const connect = async () => pool || (pool = await new sql.ConnectionPool({
    server: env.SQL_SERVER, port: +env.SQL_PORT || 1433, database: env.SQL_DATABASE, user: env.SQL_USER, password: env.SQL_PASSWORD,
    options: { encrypt: env.SQL_ENCRYPT !== 'false', trustServerCertificate: env.SQL_TRUST_CERT === 'true', enableArithAbort: true },
    connectionTimeout: 15000, requestTimeout: 25000, pool: { max: 5, idleTimeoutMillis: 30000 },
  }).connect());
  return async (text, params, maxRows) => {
    const p = await connect();
    return new Promise((resolve, reject) => {
      const req = p.request(); req.stream = true;
      params.forEach((v, i) => req.input('p' + i, v));
      const rows = []; let done = false;
      const end = e => { if (done) return; done = true; e && rows.length <= maxRows ? reject(e) : resolve({ rows: rows.slice(0, maxRows), truncated: rows.length > maxRows }); };
      req.on('row', r => { rows.push(r); if (rows.length > maxRows) { req.cancel(); end(); } });
      req.on('error', e => end(e)); req.on('done', () => end());
      req.query(text);
    });
  };
}

/* offline stand-in used by tests (SQL_MOCK=1): never touches a database */
export function mockExecutor(cfg) {
  return async (text, params, maxRows) => {
    if (/COUNT_BIG/i.test(text)) return { rows: [{ n: 123456 }], truncated: false };
    if (/INFORMATION_SCHEMA/i.test(text)) return { rows: Object.keys(Object.values(cfg.tables)[0].columns).map(c => ({ COLUMN_NAME: c })), truncated: false };
    const aliases = [...text.matchAll(/ AS \[(\w+)\]/g)].map(m => m[1]), kp = Object.keys(cfg.kpis || {});
    if (!/GROUP BY/i.test(text) && !/DISTINCT/i.test(text)) return { rows: [Object.fromEntries(aliases.map(a => [a, 42]))], truncated: false };
    return { rows: [1, 2, 3].map(i => Object.fromEntries(aliases.map(a => [a, kp.includes(a) || a === 'v' ? 1000 * i : a === 'value' ? 'Value ' + i : (a.includes('_') ? `2024-0${i}` : 'Item ' + i)]))), truncated: false };
  };
}
