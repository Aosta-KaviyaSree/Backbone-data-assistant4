"use strict";
import powerbi from "powerbi-visuals-api";
import { FormattingSettingsService } from "powerbi-visuals-utils-formattingmodel";
import "./../style/visual.less";
import { DEFAULT_URL, DEFAULT_KEY } from "./config";
import { VisualFormattingSettingsModel } from "./settings";

import IVisual = powerbi.extensibility.visual.IVisual;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;

export class Visual implements IVisual {
    private host: IVisualHost;
    private fmt = new FormattingSettingsService();
    private model = new VisualFormattingSettingsModel();
    private frame: HTMLIFrameElement;
    private msg: HTMLDivElement;
    private open: HTMLButtonElement;
    private fab: HTMLButtonElement;
    private fabLabel: HTMLSpanElement;
    private root: HTMLElement;
    private src = "";
    private ready = false;
    private timer: number | undefined;

    constructor(options: VisualConstructorOptions) {
        this.host = options.host;
        const root = options.element;
        this.root = root;
        root.classList.add("bb");
        this.frame = document.createElement("iframe");
        this.frame.title = "Backbone Data Assistant";
        this.frame.setAttribute("allow", "microphone; clipboard-write");
        this.msg = document.createElement("div");
        this.msg.className = "bb-msg";
        this.open = document.createElement("button");
        this.open.className = "bb-open";
        this.open.type = "button";
        this.open.textContent = "Open in new tab \u2197";
        this.open.onclick = () => this.src && this.host.launchUrl(this.src);
        this.fab = document.createElement("button");
        this.fab.className = "bb-fab";
        this.fab.type = "button";
        const bars = document.createElement("span");
        bars.className = "bb-bars";
        for (let i = 0; i < 5; i++) bars.appendChild(document.createElement("i"));
        this.fabLabel = document.createElement("span");
        this.fabLabel.className = "bb-lbl";
        this.fab.append(bars, this.fabLabel);
        this.fab.onclick = () => this.src && this.host.launchUrl(this.src);
        root.append(this.frame, this.msg, this.open, this.fab);
        // the assistant page tells us it loaded inside the frame
        window.addEventListener("message", (e: MessageEvent) => {
            if (e.data && e.data.type === "backbone-ready" && e.source === this.frame.contentWindow) {
                this.ready = true;
                window.clearTimeout(this.timer);
                this.msg.style.display = "none";
            }
        });
    }

    public update(options: VisualUpdateOptions) {
        const dv = options.dataViews && options.dataViews[0];
        this.model = dv ? this.fmt.populateFormattingSettingsModel(VisualFormattingSettingsModel, dv) : new VisualFormattingSettingsModel();
        const a = this.model.assistant;
        const url = (String(a.url.value || "").trim() || DEFAULT_URL).trim();
        const key = (String(a.key.value || "").trim() || DEFAULT_KEY).trim();
        const icon = String(a.mode.value && a.mode.value.value) === "icon";
        this.root.classList.toggle("bb-icon", icon);
        this.fabLabel.textContent = String(a.label.value || "");
        this.open.style.display = !icon && a.showOpen.value && url ? "block" : "none";
        if (icon) {
            this.src = /^https:\/\//i.test(url) ? url + (key ? (url.indexOf("?") >= 0 ? "&" : "?") + "key=" + encodeURIComponent(key) : "") : "";
            this.fab.title = this.src ? "Open the Backbone Data Assistant" : "Set the Assistant URL (https://...) in the Format pane";
            return;
        }
        if (!url) return this.show("Backbone Data Assistant", "Open the Format pane \u2192 Assistant and enter your Assistant URL (https://...) and Access key.");
        if (!/^https:\/\//i.test(url)) return this.show("Backbone Data Assistant", "The Assistant URL must start with https://");
        const src = url + (key ? (url.indexOf("?") >= 0 ? "&" : "?") + "key=" + encodeURIComponent(key) : "");
        if (src === this.src) return;
        this.src = src;
        this.ready = false;
        this.show("Backbone Data Assistant", "Loading\u2026");
        this.frame.src = src;
        window.clearTimeout(this.timer);
        this.timer = window.setTimeout(() => {
            if (!this.ready) this.show("The assistant could not load inside this report", "Your tenant or the assistant host may block embedding. Use \u201cOpen in new tab\u201d (voice also works there).");
        }, 8000);
    }

    private show(title: string, text: string) {
        this.msg.style.display = "flex";
        this.msg.replaceChildren();
        const h = document.createElement("div");
        h.className = "bb-t";
        h.textContent = title;
        const p = document.createElement("div");
        p.textContent = text;
        this.msg.append(h, p);
    }

    public getFormattingModel(): powerbi.visuals.FormattingModel {
        return this.fmt.buildFormattingModel(this.model);
    }
}
