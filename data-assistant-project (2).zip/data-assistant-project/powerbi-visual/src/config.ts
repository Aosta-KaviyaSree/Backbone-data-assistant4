// Optional: bake your URL/key in here BEFORE packaging (npm run package). Otherwise set them in the Format pane after importing.
export const DEFAULT_URL = "";   // e.g. "https://backbone-assistant.onrender.com"
export const DEFAULT_KEY = "";   // your ACCESS_KEY
