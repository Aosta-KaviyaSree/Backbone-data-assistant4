"use strict";
import { formattingSettings } from "powerbi-visuals-utils-formattingmodel";

class AssistantCardSettings extends formattingSettings.SimpleCard {
    url = new formattingSettings.TextInput({ name: "url", displayName: "Assistant URL (https://...)", value: "", placeholder: "https://your-host" });
    key = new formattingSettings.TextInput({ name: "key", displayName: "Access key", value: "", placeholder: "ACCESS_KEY" });
    mode = new formattingSettings.ItemDropdown({
        name: "mode", displayName: "Display",
        items: [{ value: "panel", displayName: "Chat panel (inside the report)" }, { value: "icon", displayName: "Icon (opens in a new tab)" }],
        value: { value: "panel", displayName: "Chat panel (inside the report)" }
    });
    label = new formattingSettings.TextInput({ name: "label", displayName: "Icon label", value: "Ask Backbone", placeholder: "Ask Backbone" });
    showOpen = new formattingSettings.ToggleSwitch({ name: "showOpen", displayName: "Show 'Open in new tab' button", value: true });
    name: string = "assistant";
    displayName: string = "Assistant";
    slices: formattingSettings.Slice[] = [this.mode, this.label, this.url, this.key, this.showOpen];
}

export class VisualFormattingSettingsModel extends formattingSettings.Model {
    assistant = new AssistantCardSettings();
    cards = [this.assistant];
}
