// DAX-style formulas for the loaded datasets: measures (e.g. Total Tickets = DISTINCTCOUNT('Tickets'[Tick No])) and segments
// (named filters, e.g. Open = 'Tickets'[Status] IN {"Open","In Progress"}). Admin defines them; the AI must use them.
import fs from 'fs';

const NORM = s => String(s).toLowerCase().replace(/[\s_]+/g, '');
const err = m => { throw new Error(m); };

/* ---------- tokenizer ---------- */
function tokenize(src) {
  const t = []; let i = 0;
  while (i < src.length) {
    const c = src[i], c2 = src.slice(i, i + 2);
    if (/\s/.test(c)) { i++; continue; }
    if (c2 === '//' || c2 === '--') { while (i < src.length && src[i] !== '\n') i++; continue; }
    if (c2 === '/*') { const e = src.indexOf('*/', i + 2); i = e < 0 ? src.length : e + 2; continue; }
    if (c === '"') { let s = ''; i++; for (;;) { if (i >= src.length) err('A text value is missing its closing quote (")'); if (src[i] === '"') { if (src[i + 1] === '"') { s += '"'; i += 2; continue; } break; } s += src[i++]; } i++; t.push({ k: 'str', v: s }); continue; }
    if (c === "'") { const e = src.indexOf("'", i + 1); if (e < 0) err("A table name is missing its closing quote (')"); t.push({ k: 'qid', v: src.slice(i + 1, e) }); i = e + 1; continue; }
    if (c === '[') { const e = src.indexOf(']', i); if (e < 0) err('A column name is missing its closing bracket ]'); t.push({ k: 'br', v: src.slice(i + 1, e).trim() }); i = e + 1; continue; }
    if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(src[i + 1] || ''))) { let j = i; while (j < src.length && /[0-9.]/.test(src[j])) j++; t.push({ k: 'num', v: parseFloat(src.slice(i, j)) }); i = j; continue; }
    if (['<>', '<=', '>=', '&&', '||'].includes(c2)) { t.push({ k: 'op', v: c2 }); i += 2; continue; }
    if ('+-*/=<>&,(){}'.includes(c)) { t.push({ k: 'op', v: c }); i++; continue; }
    if (/[A-Za-z_\u00C0-\uFFFF]/.test(c)) { let j = i; while (j < src.length && /[A-Za-z0-9_.\u00C0-\uFFFF]/.test(src[j])) j++; t.push({ k: 'id', v: src.slice(i, j) }); i = j; continue; }
    err(`Unexpected character "${c}"`);
  }
  return t;
}

/* ---------- parser ---------- */
function parse(tokens) {
  let p = 0; const pk = () => tokens[p], nx = () => tokens[p++];
  const op = v => pk() && pk().k === 'op' && pk().v === v;
  const kw = v => pk() && pk().k === 'id' && pk().v.toUpperCase() === v;
  const or = () => { let l = and(); while (op('||')) { nx(); l = { t: 'bin', op: '||', l, r: and() }; } return l; };
  const and = () => { let l = cmp(); while (op('&&')) { nx(); l = { t: 'bin', op: '&&', l, r: cmp() }; } return l; };
  const cmp = () => {
    let l = add();
    for (;;) {
      const x = pk();
      if (x && x.k === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(x.v)) { nx(); l = { t: 'bin', op: x.v, l, r: add() }; }
      else if (kw('IN')) { nx(); l = { t: 'in', l, r: add() }; }
      else return l;
    }
  };
  const add = () => { let l = mul(); while (op('+') || op('-') || op('&')) { const o = nx().v; l = { t: 'bin', op: o, l, r: mul() }; } return l; };
  const mul = () => { let l = un(); while (op('*') || op('/')) { const o = nx().v; l = { t: 'bin', op: o, l, r: un() }; } return l; };
  const un = () => { if (op('-')) { nx(); return { t: 'neg', e: un() }; } if (kw('NOT')) { nx(); return { t: 'not', e: un() }; } return prim(); };
  const prim = () => {
    const x = nx(); if (!x) err('The formula ends too early');
    if (x.k === 'num') return { t: 'num', v: x.v };
    if (x.k === 'str') return { t: 'str', v: x.v };
    if (x.k === 'br') return { t: 'ref', name: x.v };
    if (x.k === 'qid') return pk() && pk().k === 'br' ? { t: 'col', table: x.v, col: nx().v } : { t: 'table', name: x.v };
    if (x.k === 'op' && x.v === '(') { const e = or(); if (!op(')')) err('Missing closing parenthesis )'); nx(); return e; }
    if (x.k === 'op' && x.v === '{') { const items = []; while (!op('}')) { items.push(or()); if (op(',')) nx(); else if (!op('}')) err('Expected , or } in the list'); } nx(); return { t: 'list', items }; }
    if (x.k === 'id') {
      if (op('(')) { nx(); const args = []; while (!op(')')) { if (!pk()) err('Missing closing parenthesis )'); if (op(',')) { args.push({ t: 'blank' }); nx(); continue; } args.push(or()); if (op(',')) nx(); else if (!op(')')) err('Expected , or ) in the function arguments'); } nx(); return { t: 'call', name: x.v.toUpperCase(), args }; }
      if (/^(TRUE|FALSE)$/i.test(x.v)) return { t: 'bool', v: x.v.toUpperCase() === 'TRUE' };
      if (pk() && pk().k === 'br') return { t: 'col', table: x.v, col: nx().v };
      return { t: 'table', name: x.v };
    }
    err(`Unexpected "${x.v}"`);
  };
  const e = or(); if (p < tokens.length) err(`Unexpected "${tokens[p].v}" (is a comma or operator missing?)`); return e;
}

/* "Name = expression" or just "expression" */
export function compile(text, nameHint = '') {
  let src = String(text || '').trim(), name = String(nameHint || '').trim();
  const i = src.indexOf('=');
  if (i > 0 && !'<>'.includes(src[i - 1]) && !'>='.includes(src[i + 1] || ' ')) {
    const cand = src.slice(0, i).trim().replace(/^\[(.*)\]$/, '$1');
    if (/^[^()\[\]{}"'=<>&|,+*\/]+$/.test(cand) && !/^(IF|AND|OR|NOT)$/i.test(cand)) { name = name || cand; src = src.slice(i + 1).trim(); }
  }
  if (!src) err('The formula is empty');
  return { name, ast: parse(tokenize(src)) };
}

/* ---------- evaluator ---------- */
const colKey = (T, n) => T.cols.includes(n) ? n : T.cols.find(c => NORM(c) === NORM(n));
const isNum = v => typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v)));
const eqv = (a, b) => (a == null || b == null) ? (a == null && b == null) : (isNum(a) && isNum(b)) ? Number(a) === Number(b) : String(a).toLowerCase() === String(b).toLowerCase();
const cmpv = (a, b) => (isNum(a) && isNum(b)) ? Number(a) - Number(b) : String(a ?? '').toLowerCase() < String(b ?? '').toLowerCase() ? -1 : String(a ?? '').toLowerCase() > String(b ?? '').toLowerCase() ? 1 : 0;
const truthy = v => v === true || (typeof v === 'number' && v !== 0);
const colOf = (n, ctx) => {
  if (n.t === 'col' || n.t === 'ref') { const k = colKey(ctx.T, n.t === 'col' ? n.col : n.name); if (!k) err(`Column "${n.t === 'col' ? n.col : n.name}" was not found in this dataset. Columns: ${ctx.T.cols.join(', ')}`); return k; }
  return err('This function needs a column, for example SUM(\'Table\'[Amount])');
};
const dateParts = v => { const m = String(v ?? '').match(/^(\d{4})-(\d{2})-(\d{2})/); return m ? { y: +m[1], m: +m[2], d: +m[3] } : null; };
const AGG = new Set(['COUNTROWS', 'COUNT', 'COUNTA', 'DISTINCTCOUNT', 'DISTINCTCOUNTNOBLANK', 'SUM', 'AVERAGE', 'MIN', 'MAX']);
export const FUNCTIONS = ['DISTINCTCOUNT', 'COUNT', 'COUNTROWS', 'SUM', 'AVERAGE', 'MIN', 'MAX', 'CALCULATE', 'FILTER', 'ALL', 'DIVIDE', 'IF', 'SWITCH', 'AND', 'OR', 'NOT', 'ISBLANK', 'COALESCE', 'ROUND', 'ABS', 'YEAR', 'MONTH', 'DAY', 'TODAY', 'DATE', 'UPPER', 'LOWER', 'CONTAINSSTRING'];

function ev(n, ctx, row) {
  if (ctx.depth > 25) err('Formulas refer to each other in a loop');
  switch (n.t) {
    case 'num': case 'str': case 'bool': return n.v;
    case 'blank': return null;
    case 'list': return n.items.map(i => ev(i, ctx, row));
    case 'table': return ctx.rows.length;
    case 'neg': return -(Number(ev(n.e, ctx, row)) || 0);
    case 'not': return !truthy(ev(n.e, ctx, row));
    case 'col': case 'ref': {
      if (n.t === 'ref') { const m = ctx.measures.get(NORM(n.name)); if (m) return ev(m.ast, { ...ctx, depth: ctx.depth + 1 }, undefined); }
      const k = colOf(n, ctx);
      if (!row) err(`"${n.t === 'col' ? n.col : n.name}" is a column. Use it inside an aggregation (SUM, DISTINCTCOUNT...) or inside a CALCULATE filter.`);
      return row[k];
    }
    case 'in': { const l = ev(n.l, ctx, row), r = ev(n.r, ctx, row); return (Array.isArray(r) ? r : [r]).some(x => eqv(l, x)); }
    case 'bin': {
      if (n.op === '&&') return truthy(ev(n.l, ctx, row)) && truthy(ev(n.r, ctx, row));
      if (n.op === '||') return truthy(ev(n.l, ctx, row)) || truthy(ev(n.r, ctx, row));
      const a = ev(n.l, ctx, row), b = ev(n.r, ctx, row);
      switch (n.op) {
        case '=': return eqv(a, b); case '<>': return !eqv(a, b);
        case '<': return cmpv(a, b) < 0; case '>': return cmpv(a, b) > 0; case '<=': return cmpv(a, b) <= 0; case '>=': return cmpv(a, b) >= 0;
        case '&': return String(a ?? '') + String(b ?? '');
        case '+': return (Number(a) || 0) + (Number(b) || 0); case '-': return (Number(a) || 0) - (Number(b) || 0); case '*': return (Number(a) || 0) * (Number(b) || 0);
        case '/': { const d = Number(b) || 0; return d === 0 ? null : (Number(a) || 0) / d; }
      }
      return err('Unknown operator');
    }
    case 'call': return call(n, ctx, row);
  }
  return err('Unsupported formula part');
}

function call(n, ctx, row) {
  const f = n.name, a = n.args, vals = k => ctx.rows.map(r => r[k]).filter(v => v != null && v !== '');
  if (AGG.has(f)) {
    if (f === 'COUNTROWS') return ctx.rows.length;
    const k = colOf(a[0] || err(`${f} needs a column`), ctx), v = vals(k);
    if (f === 'COUNT' || f === 'COUNTA') return v.length;
    if (f === 'DISTINCTCOUNT' || f === 'DISTINCTCOUNTNOBLANK') return new Set(v.map(x => String(x).toLowerCase())).size;
    if (f === 'SUM') return v.reduce((s, x) => s + (Number(x) || 0), 0);
    if (f === 'AVERAGE') return v.length ? v.reduce((s, x) => s + (Number(x) || 0), 0) / v.length : null;
    if (!v.length) return null;
    return v.reduce((m, x) => (f === 'MIN' ? cmpv(x, m) < 0 : cmpv(x, m) > 0) ? x : m);
  }
  switch (f) {
    case 'CALCULATE': {
      if (!a.length) err('CALCULATE needs a formula as its first argument');
      let rows = ctx.rows; const fl = a.slice(1);
      if (fl.some(x => x.t === 'call' && ['ALL', 'REMOVEFILTERS', 'ALLEXCEPT'].includes(x.name))) rows = ctx.all;
      for (const x of fl) {
        if (x.t === 'call' && ['ALL', 'REMOVEFILTERS', 'ALLEXCEPT'].includes(x.name)) continue;
        const pred = x.t === 'call' && x.name === 'FILTER' ? x.args[1] : x;
        rows = rows.filter(r => truthy(ev(pred, ctx, r)));
      }
      return ev(a[0], { ...ctx, rows }, undefined);
    }
    case 'DIVIDE': { const d = Number(ev(a[1], ctx, row)) || 0; return d === 0 ? (a[2] ? ev(a[2], ctx, row) : null) : (Number(ev(a[0], ctx, row)) || 0) / d; }
    case 'IF': return truthy(ev(a[0], ctx, row)) ? ev(a[1], ctx, row) : (a[2] ? ev(a[2], ctx, row) : null);
    case 'SWITCH': { const x = ev(a[0], ctx, row); for (let i = 1; i + 1 < a.length; i += 2) if (eqv(x, ev(a[i], ctx, row))) return ev(a[i + 1], ctx, row); return a.length % 2 === 0 ? ev(a[a.length - 1], ctx, row) : null; }
    case 'AND': return a.every(x => truthy(ev(x, ctx, row))); case 'OR': return a.some(x => truthy(ev(x, ctx, row))); case 'NOT': return !truthy(ev(a[0], ctx, row));
    case 'ISBLANK': { const v = ev(a[0], ctx, row); return v == null || v === ''; }
    case 'COALESCE': for (const x of a) { const v = ev(x, ctx, row); if (v != null && v !== '') return v; } return null;
    case 'ROUND': { const v = Number(ev(a[0], ctx, row)); const d = a[1] ? Number(ev(a[1], ctx, row)) : 0; return isNaN(v) ? null : Math.round(v * 10 ** d) / 10 ** d; }
    case 'ABS': return Math.abs(Number(ev(a[0], ctx, row)) || 0);
    case 'YEAR': case 'MONTH': case 'DAY': { const d = dateParts(ev(a[0], ctx, row)); return d ? d[f === 'YEAR' ? 'y' : f === 'MONTH' ? 'm' : 'd'] : null; }
    case 'TODAY': return new Date().toISOString().slice(0, 10);
    case 'DATE': return `${String(ev(a[0], ctx, row)).padStart(4, '0')}-${String(ev(a[1], ctx, row)).padStart(2, '0')}-${String(ev(a[2], ctx, row)).padStart(2, '0')}`;
    case 'UPPER': return String(ev(a[0], ctx, row) ?? '').toUpperCase(); case 'LOWER': return String(ev(a[0], ctx, row) ?? '').toLowerCase();
    case 'CONTAINSSTRING': return String(ev(a[0], ctx, row) ?? '').toLowerCase().includes(String(ev(a[1], ctx, row) ?? '').toLowerCase());
    case 'BLANK': return null;
    case 'ALL': case 'REMOVEFILTERS': case 'ALLEXCEPT': case 'FILTER': return err(`${f} can only be used inside CALCULATE`);
  }
  return err(`Function ${f} is not supported yet. Supported: ${FUNCTIONS.join(', ')}`);
}

export function evalMeasure(ast, T, measures, rows, all) { return ev(ast, { T, rows, all: all || T.rows, measures, depth: 0 }, undefined); }
export function evalPredicate(ast, T, measures, row) { return truthy(ev(ast, { T, rows: T.rows, all: T.rows, measures, depth: 0 }, row)); }

/* ---------- store + query ---------- */
const OPS = { '=': eqv, '!=': (a, b) => !eqv(a, b), '>': (a, b) => cmpv(a, b) > 0, '<': (a, b) => cmpv(a, b) < 0, '>=': (a, b) => cmpv(a, b) >= 0, '<=': (a, b) => cmpv(a, b) <= 0,
  contains: (a, b) => String(a ?? '').toLowerCase().includes(String(b).toLowerCase()), in: (a, b) => String(b).split(',').some(x => eqv(a, x.trim())) };

export function createFormulas(file, helpers = {}) {
  let data = {}; try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { /* none yet */ }
  const st = { version: 1 };
  const persist = () => { fs.writeFileSync(file, JSON.stringify(data, null, 2)); st.version++; };
  const def = t => data[t] || { measures: [], segments: [], notes: '' };
  const build = d => {
    const measures = new Map(), segs = new Map();
    d.measures.forEach(m => { const c = compile(m.formula, m.name); measures.set(NORM(m.name), { ...m, ast: c.ast }); });
    d.segments.forEach(s => { segs.set(NORM(s.name), { ...s, ast: compile(s.condition).ast }); });
    return { measures, segs };
  };
  const sample = (T, ast, M, kind) => { const t0 = Date.now(); if (kind === 'segment') { const n = T.rows.filter(r => evalPredicate(ast, T, M, r)).length; return { matched: n, total: T.rows.length, ms: Date.now() - t0 }; } const v = evalMeasure(ast, T, M, T.rows); return { value: typeof v === 'number' ? Math.round(v * 10000) / 10000 : v, ms: Date.now() - t0 }; };
  return {
    get version() { return st.version; },
    get: def, all: () => data,
    hasAny: tables => Object.keys(tables).some(t => def(t).measures.length || def(t).segments.length),
    /* validate (and evaluate on the loaded data) a whole dataset definition, then save */
    save(table, payload, T) {
      const d = { measures: [], segments: [], notes: String(payload.notes || '').slice(0, 2000) }, names = new Set(), results = [];
      for (const [kind, list, key] of [['measure', payload.measures || [], 'measures'], ['segment', payload.segments || [], 'segments']]) {
        for (const x of list) {
          const name = String(x.name || '').trim().slice(0, 60);
          if (!name) throw new Error(`Every ${kind} needs a name.`);
          if (names.has(kind + NORM(name))) throw new Error(`Two ${kind}s are called "${name}".`);
          names.add(kind + NORM(name));
          const text = String(kind === 'measure' ? x.formula : x.condition || '').trim();
          try { const c = compile(text, name); d[key].push(kind === 'measure' ? { name, formula: text.replace(new RegExp('^\\s*\\[?' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\]?\\s*=\\s*', 'i'), ''), description: String(x.description || '').slice(0, 300), format: x.format || 'auto' } : { name, condition: text, description: String(x.description || '').slice(0, 300) }); void c; }
          catch (e) { throw new Error(`${kind[0].toUpperCase() + kind.slice(1)} "${name}": ${e.message}`); }
        }
      }
      const B = build(d);
      if (T) {
        for (const m of B.measures.values()) { try { results.push({ name: m.name, ok: true, ...sample(T, m.ast, B.measures, 'measure') }); } catch (e) { throw new Error(`Measure "${m.name}": ${e.message}`); } }
        for (const s of B.segs.values()) { try { results.push({ name: s.name, ok: true, ...sample(T, s.ast, B.measures, 'segment') }); } catch (e) { throw new Error(`Segment "${s.name}": ${e.message}`); } }
      }
      data[table] = d; persist(); return { ok: true, results };
    },
    test(kind, text, name, T, others = {}) {
      try {
        const d = { measures: (others.measures || []).filter(m => m.name && m.formula && NORM(m.name) !== NORM(name || '')), segments: [] };
        const M = new Map(); for (const m of d.measures) { try { M.set(NORM(m.name), { ...m, ast: compile(m.formula, m.name).ast }); } catch { /* ignore broken siblings */ } }
        const c = compile(text, name);
        if (kind === 'measure' && c.name) M.set(NORM(c.name), { name: c.name, ast: c.ast });
        return { ok: true, name: c.name || undefined, ...sample(T, c.ast, M, kind) };
      } catch (e) { return { ok: false, error: e.message }; }
    },
    toolDef(tables) {
      const ms = [], ss = [];
      for (const t of Object.keys(tables)) { def(t).measures.forEach(m => ms.push(m.name)); def(t).segments.forEach(s => ss.push(s.name)); }
      return { name: 'query_measures', description: `Evaluate the admin-defined business formulas (measures) on a dataset, optionally for named segments and grouped. ALWAYS use this when a question matches a measure: never count rows yourself. Measures: ${ms.join(', ') || '-'}. Segments: ${ss.join(', ') || '-'}.`,
        input_schema: { type: 'object', properties: { table: { type: 'string' }, measures: { type: 'array', items: { type: 'string' } }, segments: { type: 'array', items: { type: 'string' }, description: 'Named filters, all applied together' },
          group_by: { type: 'array', items: { type: 'string' } }, time_bucket: { type: 'object', properties: { column: { type: 'string' }, bucket: { type: 'string', enum: ['year', 'quarter', 'month', 'day', 'weekday', 'hour'] } }, required: ['column', 'bucket'] },
          date_column: { type: 'string' }, date_from: { type: 'string' }, date_to: { type: 'string', description: 'inclusive yyyy-mm-dd' },
          filters: { type: 'array', items: { type: 'object', properties: { column: { type: 'string' }, op: { type: 'string', enum: Object.keys(OPS) }, value: { type: 'string' } }, required: ['column', 'op', 'value'] } },
          order_by: { type: 'string' }, desc: { type: 'boolean' }, limit: { type: 'integer' } }, required: ['measures'] } };
    },
    info(tables) {
      const L = [];
      for (const [t, T] of Object.entries(tables)) {
        const d = def(t); if (!d.measures.length && !d.segments.length && !d.notes) continue;
        L.push(`\nADMIN-DEFINED FORMULAS for dataset "${t}" (the source of truth: use the query_measures tool, never recount rows yourself):`);
        d.measures.forEach(m => L.push(`- measure "${m.name}" = ${m.formula}${m.description ? '   // ' + m.description : ''}${m.format && m.format !== 'auto' ? ` [show as ${m.format}]` : ''}`));
        d.segments.forEach(s => L.push(`- segment "${s.name}" = ${s.condition}${s.description ? '   // ' + s.description : ''}`));
        if (d.notes) L.push('- business notes: ' + d.notes);
        void T;
      }
      return L.length ? L.join('\n') + '\nIf a question uses a word like open/closed/pending that matches a segment, apply that segment. If it asks "how many tickets" and a count measure exists, use the measure.' : '';
    },
    run(a, tables) {
      try {
        const names = [].concat(a.measures || []); if (!names.length) err('Pass at least one measure');
        let tn = a.table && tables[a.table] ? a.table : Object.keys(tables).find(t => names.every(n => def(t).measures.some(m => NORM(m.name) === NORM(n)))) || err(`No dataset has all these measures: ${names.join(', ')}`);
        const T = tables[tn], B = build(def(tn));
        const mm = names.map(n => B.measures.get(NORM(n)) || err(`Unknown measure "${n}". Available: ${[...B.measures.values()].map(m => m.name).join(', ')}`));
        let rows = T.rows;
        for (const s of a.segments || []) { const S = B.segs.get(NORM(s)) || err(`Unknown segment "${s}". Available: ${[...B.segs.values()].map(x => x.name).join(', ') || '-'}`); rows = rows.filter(r => evalPredicate(S.ast, T, B.measures, r)); }
        const kc = c => colKey(T, c) || err(`Unknown column "${c}". Columns: ${T.cols.join(', ')}`);
        const dc = a.date_column ? kc(a.date_column) : T.cols.find(c => T.types[c] === 'date');
        if ((a.date_from || a.date_to) && !dc) err('This dataset has no date column');
        if (a.date_from) rows = rows.filter(r => r[dc] && String(r[dc]).slice(0, 10) >= a.date_from);
        if (a.date_to) rows = rows.filter(r => r[dc] && String(r[dc]).slice(0, 10) <= a.date_to);
        for (const f of a.filters || []) { const k = kc(f.column), o = OPS[f.op] || err(`Unsupported operator ${f.op}`); rows = rows.filter(r => o(r[k], f.value)); }
        const dims = (a.group_by || []).map(kc), tb = a.time_bucket && { col: kc(a.time_bucket.column), b: a.time_bucket.bucket }, alias = tb && `${tb.col}_${tb.b}`;
        const groups = new Map();
        for (const r of rows) { const bv = tb ? helpers.bucketOf(r[tb.col], tb.b) : ''; if (bv === null) continue; const key = JSON.stringify([...dims.map(d => r[d]), bv]); (groups.get(key) || groups.set(key, { r, rows: [] }).get(key)).rows.push(r); }
        let out = [...groups.values()].map(g => { const o = {}; dims.forEach(d => (o[d] = g.r[d])); if (tb) o[alias] = helpers.bucketOf(g.r[tb.col], tb.b); for (const m of mm) { const v = evalMeasure(m.ast, T, B.measures, g.rows, T.rows); o[m.name] = typeof v === 'number' ? Math.round(v * 10000) / 10000 : v; } return o; });
        if (!groups.size && !dims.length && !tb) out = [Object.fromEntries(mm.map(m => { const v = evalMeasure(m.ast, T, B.measures, [], T.rows); return [m.name, typeof v === 'number' ? Math.round(v * 10000) / 10000 : v]; }))];
        const ob = a.order_by || (tb ? alias : mm[0].name), asc = a.order_by ? a.desc === false : !!tb;
        out.sort((x, y) => (asc ? 1 : -1) * cmpv(x[ob], y[ob]));
        const lim = Math.max(1, Math.min(Number(a.limit) || 50, 200));
        return { sql: `FORMULAS ON ${tn}: ` + mm.map(m => `${m.name} = ${m.formula}`).join(' ; ') + ((a.segments || []).length ? ' | SEGMENTS: ' + a.segments.map(s => `${s} (${B.segs.get(NORM(s)).condition})`).join(' ; ') : ''), table: tn, rowCount: out.length, truncated: out.length > lim, rows: out.slice(0, lim) };
      } catch (e) { return { error: String(e.message).slice(0, 400) }; }
    },
  };
}
