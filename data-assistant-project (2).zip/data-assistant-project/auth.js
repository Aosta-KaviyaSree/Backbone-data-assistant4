// Accounts, roles (admin / user) and signed login tokens. No external dependencies.
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

const b64 = b => Buffer.from(b).toString('base64url');
const read = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const NAME = /^[a-z0-9._@-]{3,40}$/;

export function createAuth(dir, { ttlHours = 12 } = {}) {
  const uf = path.join(dir, 'users.json'), sf = path.join(dir, 'auth-settings.json'), kf = path.join(dir, '.session-secret');
  fs.mkdirSync(dir, { recursive: true });
  let users = read(uf, []), settings = Object.assign({ allowSignup: false }, read(sf, {}));
  let secret = process.env.SESSION_SECRET || (fs.existsSync(kf) ? fs.readFileSync(kf, 'utf8') : '');
  if (!secret) { secret = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(kf, secret, { mode: 0o600 }); }
  const saveU = () => fs.writeFileSync(uf, JSON.stringify(users, null, 2), { mode: 0o600 });
  const pub = u => ({ id: u.id, username: u.username, role: u.role, created: u.created, lastLogin: u.lastLogin || null });
  const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) => `s1$${salt}$${crypto.scryptSync(pw, salt, 64).toString('hex')}`;
  const same = (pw, h) => { const [, salt, hx] = String(h).split('$'); const a = Buffer.from(hx || '', 'hex'), b = crypto.scryptSync(pw, salt || '', 64); return a.length === b.length && crypto.timingSafeEqual(a, b); };
  const sign = u => { const body = b64(JSON.stringify({ u: u.id, e: Date.now() + ttlHours * 3600e3 })); return body + '.' + crypto.createHmac('sha256', secret).update(body).digest('base64url'); };
  const tries = new Map();
  const admins = () => users.filter(u => u.role === 'admin').length;
  const check = (username, password) => {
    username = String(username || '').trim().toLowerCase();
    if (!NAME.test(username)) throw new Error('Username: 3-40 characters, letters, numbers and . _ @ - only.');
    if (String(password || '').length < 8) throw new Error('Password must be at least 8 characters.');
    return username;
  };
  return {
    hasUsers: () => users.length > 0,
    settings: () => ({ ...settings }),
    setSettings(s) { settings = { ...settings, allowSignup: !!s.allowSignup }; fs.writeFileSync(sf, JSON.stringify(settings)); },
    create({ username, password, role = 'user' }) {
      username = check(username, password);
      if (users.some(u => u.username === username)) throw new Error('That username is already taken.');
      const u = { id: crypto.randomBytes(6).toString('hex'), username, role: role === 'admin' ? 'admin' : 'user', pass: hash(password), created: new Date().toISOString() };
      users.push(u); saveU(); return pub(u);
    },
    login(username, password, ip = '') {
      username = String(username || '').trim().toLowerCase();
      const k = ip + '|' + username, t = tries.get(k) || { n: 0, until: 0 };
      if (Date.now() < t.until) throw new Error('Too many attempts. Wait a minute and try again.');
      const u = users.find(x => x.username === username);
      if (!u || !same(String(password || ''), u.pass)) { t.n++; if (t.n >= 5) { t.until = Date.now() + 60000; t.n = 0; } tries.set(k, t); throw new Error('Wrong username or password.'); }
      tries.delete(k); u.lastLogin = new Date().toISOString(); saveU();
      return { token: sign(u), user: pub(u) };
    },
    verify(token) {
      const [body, sig] = String(token || '').split('.');
      if (!body || !sig || crypto.createHmac('sha256', secret).update(body).digest('base64url') !== sig) return null;
      let p; try { p = JSON.parse(Buffer.from(body, 'base64url').toString()); } catch { return null; }
      if (!p.e || p.e < Date.now()) return null;
      const u = users.find(x => x.id === p.u); return u ? pub(u) : null;
    },
    list: () => users.map(pub),
    update(id, { password, role }) {
      const u = users.find(x => x.id === id); if (!u) throw new Error('User not found.');
      if (role && role !== u.role) { if (u.role === 'admin' && admins() <= 1) throw new Error('At least one admin is required.'); u.role = role === 'admin' ? 'admin' : 'user'; }
      if (password) { check(u.username, password); u.pass = hash(password); }
      saveU(); return pub(u);
    },
    remove(id) {
      const u = users.find(x => x.id === id); if (!u) throw new Error('User not found.');
      if (u.role === 'admin' && admins() <= 1) throw new Error('You cannot delete the last admin.');
      users = users.filter(x => x.id !== id); saveU();
    },
    changeOwnPassword(id, oldPw, newPw) {
      const u = users.find(x => x.id === id); if (!u || !same(String(oldPw || ''), u.pass)) throw new Error('Current password is wrong.');
      check(u.username, newPw); u.pass = hash(newPw); saveU();
    },
  };
}
