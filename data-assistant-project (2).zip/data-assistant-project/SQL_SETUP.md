# Live SQL Server for ONE module

How it works: you describe ONE module (a SQL view + your KPI formulas) in `module.config.json`. The AI never writes formulas: it picks KPI names, and the server builds parameterised, read-only T-SQL from YOUR formulas, runs it on the live database, and the AI explains the result. Every executed SQL statement is saved in the usage log and printed by `npm run report:full`.

## 1. Prepare SQL Server (once)
Create one view for the module (joins done once, columns named clearly) and a READ-ONLY login that can see only that view:
```sql
CREATE VIEW dbo.vw_OP_Module AS
SELECT ... ;            -- your joins; leave out names/phones/addresses you do not need
GO
CREATE LOGIN assistant_readonly WITH PASSWORD = 'use-a-long-random-password';
CREATE USER  assistant_readonly FOR LOGIN assistant_readonly;
GRANT SELECT ON dbo.vw_OP_Module TO assistant_readonly;
```
## 2. Network
The machine running this app must reach SQL Server. If the database is on-premises, run the app on a server INSIDE your network (or use a VPN/gateway). A free cloud host cannot reach a private SQL Server. The app also needs outbound internet to reach the AI service.

## 3. Settings
Copy `module.config.example.json` to `module.config.json`, then edit:
- `tables.<name>.source` = your view; `dateColumn`; `columns` (only list columns the assistant may use; give each a `type`: id / text / number / date, and a plain description)
- `kpis` = YOUR formulas. `expression` is T-SQL using the alias `t.`, e.g. `COUNT(DISTINCT t.iop_id)` or `SUM(CASE WHEN t.cPatType = 'NEW' THEN 1 ELSE 0 END)`
- `rules` = business definitions in plain sentences; `examples` = a few question -> call samples (the AI follows these)
- `fiscalStartMonth` = 4 for April-March financial years (`fy`, `fyq` buckets)
In `.env` set `SQL_SERVER`, `SQL_DATABASE`, `SQL_USER`, `SQL_PASSWORD` (see `.env.example`).

## 4. Test it
`npm run sql:check` connects, confirms every configured column exists in the view, runs each KPI formula once (value + time) and each example. Fix anything marked with a cross, then `npm start`.

## 5. Safety built in
Read-only login; KPI mode only by default (`allowAdHocSql: false`); values are sent as SQL parameters (no injection); column/KPI names are checked against the config; max rows (`maxRows`, default 200); 25 s query timeout. If you turn on `allowAdHocSql`, a validator allows only a single SELECT on the configured views and blocks INSERT/UPDATE/DELETE/DROP/EXEC/INTO etc.

## 6. Privacy (please read)
Query RESULTS (not your database) are sent to the AI provider so it can write the answer. KPI mode sends aggregates only, which is the recommended setting for patient data. Keep patient identifiers out of the config, keep `LOG_CONTENT=false`, and get your organisation's approval before using an external AI service. For a fully private setup use `PROVIDER=ollama` (a model running on your own server).

## 7. Status
The query builder and safety checks are unit-tested, and the whole flow is tested against a stand-in database. It has NOT been run against a real SQL Server by the author: run `npm run sql:check` first. Requires SQL Server 2012 or later.
